const items = [

  // MOVEMENT
  {name:"Warrior Boots",category:"Movement"},
  {name:"Tough Boots",category:"Movement"},
  {name:"Magic Shoes",category:"Movement"},
  {name:"Arcane Boots",category:"Movement"},
  {name:"Swift Boots",category:"Movement"},
  {name:"Rapid Boots",category:"Movement"},
  {name:"Demon Boots", category:"Movement"},

  // PHYSICAL DAMAGE
  {name:"Blade of Despair",category:"Physical Damage"},
  {name:"Demon Hunter Sword",category:"Physical Damage"},
  {name:"Golden Staff",category:"Physical Damage"},
  {name:"Corrosion Scythe",category:"Physical Damage"},
  {name:"Windtalker",category:"Physical Damage"},
  {name:"Malefic Gun",category:"Physical Damage"},
  {name:"Malefic Roar",category:"Physical Damage"},
  {name:"Berserker's Fury",category:"Physical Damage"},
  {name:"Haas Claws",category:"Physical Damage"},
  {name:"Sea Halberd",category:"Physical Damage"},
  {name:"Great Dragon Spear",category:"Physical Damage"},
  {name:"Hunter Strike",category:"Physical Damage"},
  {name:"Blade of the Heptaseas",category:"Physical Damage"},
  {name:"War Axe",category:"Physical Damage"},
  {name:"Endless Battle",category:"Physical Damage"},
  {name:"Rose Gold Meteor",category:"Physical Damage"},
  {name:"Sky Piercer",category:"Physical Damage"},

  // MAGIC DAMAGE
  {name:"Holy Crystal",category:"Magic Damage"},
  {name:"Genius Wand",category:"Magic Damage"},
  {name:"Glowing Wand",category:"Magic Damage"},
  {name:"Divine Glaive",category:"Magic Damage"},
  {name:"Lightning Truncheon",category:"Magic Damage"},
  {name:"Ice Queen Wand",category:"Magic Damage"},
  {name:"Blood Wings",category:"Magic Damage"},
  {name:"Clock of Destiny",category:"Magic Damage"},
  {name:"Starlium Scythe",category:"Magic Damage"},
  {name:"Feather of Heaven",category:"Magic Damage"},
  {name:"Concentrated Energy",category:"Magic Damage"},
  {name:"Wishing Lantern",category:"Magic Damage"},
  {name:"Flask of the Oasis",category:"Magic Damage"},
  {name:"Fleeting Time",category:"Magic Damage"},
  {name:"Winter Crown",category:"Magic Damage"},

  // PHYSICAL DEFENSE
  {name:"Blade Armor",category:"Physical Defense"},
  {name:"Dominance Ice",category:"Physical Defense"},
  {name:"Antique Cuirass",category:"Physical Defense"},
  {name:"Brute Force Breastplate",category:"Physical Defense"},
  {name:"Chastise Pauldron",category:"Physical Defense"},
  {name:"Thunder Belt",category:"Physical Defense"},

  // MAGIC DEFENSE
  {name:"Athena Shield",category:"Magic Defense"},
  {name:"Radiant Armor",category:"Magic Defense"},
  {name:"Oracle",category:"Magic Defense"},

  // HP / HYBRID DEFENSE
  {name:"Immortality",category:"Hybrid Defense"},
  {name:"Guardian Helmet",category:"Hybrid Defense"},
  {name:"Queen's Wings",category:"Hybrid Defense"},
  {name:"Cursed Helmet",category:"Hybrid Defense"},
  
  // JUNGLE
{name:"Flame Retribution",category:"Jungle"},
{name:"Ice Retribution",category:"Jungle"},
{name:"Bloody Retribution",category:"Jungle"},

// ROAM
{name:"Conceal",category:"Roam"},
{name:"Encourage",category:"Roam"},
{name:"Favor",category:"Roam"},
{name:"Dire Hit",category:"Roam"}
];

const itemDetails = {

// MOVEMENT
"Warrior Boots": {cost:720, stats:"+40 Movement Speed • +22 Physical Defense", passive:"Valor: Basic attacks deal reduced damage to you."},
"Tough Boots": {cost:700, stats:"+40 Movement Speed • +18 Magic Defense", passive:"Fortitude: 30% CC duration reduction."},
"Magic Shoes": {cost:710, stats:"+40 Movement Speed • +10% Cooldown Reduction", passive:"Cooldown reduction for skill-based heroes."},
"Arcane Boots": {cost:690, stats:"+40 Movement Speed • +10 Magic Penetration", passive:"Extra magic penetration."},
"Swift Boots": {cost:710, stats:"+40 Movement Speed • +15% Attack Speed", passive:"Boosts attack speed."},
"Rapid Boots": {cost:750, stats:"+65 Movement Speed", passive:"Very high movement speed out of combat."},
"Demon Boots": {cost:720, stats:"+40 Movement Speed • +6 Mana Regen", passive:"Restore mana after kills/assists."},

// PHYSICAL DAMAGE
"Blade of Despair": {cost:3010, stats:"+160 Physical Attack", passive:"Despair: Deals extra damage to low HP enemies."},
"Demon Hunter Sword": {cost:2180, stats:"+35 Physical Attack • +25% Attack Speed", passive:"Devour: Bonus damage based on enemy HP."},
"Golden Staff": {cost:2000, stats:"+55 Physical Attack • +15% Attack Speed", passive:"Infinite Strike: Converts crit into attack speed."},
"Corrosion Scythe": {cost:2050, stats:"+30 Physical Attack • +35% Attack Speed • +5% Move Speed", passive:"Corrosion: Slows enemies with attacks."},
"Windtalker": {cost:1880, stats:"+40% Attack Speed • +20 Move Speed • +10% Crit Chance", passive:"Typhoon: Chain magic damage on attacks."},
"Malefic Gun": {cost:2120, stats:"+35 Physical Attack • +15% Attack Speed", passive:"Extends attack range and armor penetration."},
"Malefic Roar": {cost:2060, stats:"+60 Physical Attack • +20% Physical Penetration", passive:"Armor Buster: More damage to high-defense enemies."},
"Berserker's Fury": {cost:2390, stats:"+65 Physical Attack • +25% Crit Chance", passive:"Doom: Crit damage increased."},
"Haas Claws": {cost:2020, stats:"+40 Physical Attack • +15% Attack Speed • +20% Crit Chance • +20% Lifesteal", passive:"Frenzy: Critical strikes grant 20% extra Attack Speed for 2 seconds."},
"Sea Halberd": {cost:2050, stats:"+80 Physical Attack • +25% Attack Speed", passive:"Life Drain: Reduces enemy healing."},
"Great Dragon Spear": {cost:2140, stats:"+70 Physical Attack • +10% Cooldown Reduction", passive:"Dragon Flight: Movement speed after Ultimate."},
"Hunter Strike": {cost:2010, stats:"+80 Physical Attack • +10% Cooldown Reduction", passive:"Retribution: Speed boost after hitting enemy."},
"Blade of the Heptaseas": {cost:1950, stats:"+70 Physical Attack • +15 Physical Penetration", passive:"Ambush: Bonus damage after no combat."},
"War Axe": {cost:2100, stats:"+35 Physical Attack • +10% Cooldown Reduction • +550 HP", passive:"Fighting Spirit stacks increase damage."},
"Endless Battle": {cost:2330, stats:"+65 Physical Attack • +250 HP • +5 Mana Regen • +10% CDR", passive:"True Damage after skill cast."},
"Rose Gold Meteor": {cost:1820, stats:"+60 Physical Attack • +30 Magic Defense", passive:"Lifeline: Shield on low HP."},
"Sky Piercer": {cost:1500, stats:"+60 Adaptive Attack", passive:"Execution: Instantly finishes low HP enemies."},

// MAGIC DAMAGE
"Holy Crystal": {cost:3000, stats:"+185 Magic Power", passive:"Mystery: Increases Magic Power."},
"Genius Wand": {cost:2000, stats:"+75 Magic Power • +5% Move Speed", passive:"Magic: Reduces enemy Magic Defense."},
"Glowing Wand": {cost:2050, stats:"+75 Magic Power • +400 HP", passive:"Scorch: Burn damage over time."},
"Lightning Truncheon": {cost:2250, stats:"+75 Magic Power • +20 Mana Regen • +10% CDR", passive:"Resonate: Lightning burst damage."},
"Divine Glaive": {cost:1970, stats:"+65 Magic Power • +40% Magic Penetration", passive:"Spellbreaker: More penetration on magic defense."},
"Blood Wings": {cost:2100, stats:"+150 Magic Power • +500 HP", passive:"Guard: Grants shield."},
"Ice Queen Wand": {cost:2040, stats:"+75 Magic Power • +10% Spell Vamp • +150 Mana", passive:"Ice Bound: Skills slow enemies."},
"Feather of Heaven": {cost:2030, stats:"+65 Magic Power • +30% Attack Speed", passive:"Affliction: Magic damage on attacks."},
"Concentrated Energy": {cost:2020, stats:"+70 Magic Power • +25% Spell Vamp", passive:"Recharge: Heal after kills."},
"Starlium Scythe": {cost:2220, stats:"+70 Magic Power • +10% CDR • +250 HP", passive:"Crisis: True damage after skills."},
"Clock of Destiny": {cost:2030, stats:"+45 Magic Power • +500 Mana • +600 HP", passive:"Time: Stacks Magic Power and HP."},
"Fleeting Time": {cost:2050, stats:"+70 Magic Power • +15% CDR", passive:"Timestream: Ultimate cooldown reduced after kills."},
"Wishing Lantern": {cost:2250, stats:"+75 Magic Power • +400 Mana • +10% CDR", passive:"Butterfly Goddess: After enough magic damage, summons a butterfly that deals damage based on the enemy’s current HP."},
"Winter Crown": {cost:1910, stats:"+45 Adaptive Attack • +400 HP • +5% CDR", passive:"Frozen: Become untargetable and immune to damage for 2 seconds (100s cooldown)."},

// PHYSICAL DEFENSE
"Antique Cuirass": {cost:2170, stats:"+920 HP • +54 Physical Defense", passive:"Deter: Reduces enemy Physical Attack."},
"Blade Armor": {cost:1910, stats:"+90 Physical Defense", passive:"Counterstrike: Reflects Basic Attack damage."},
"Brute Force Breastplate": {cost:1870, stats:"+600 HP • +30 Physical Defense", passive:"Brute Force: Gain movement speed and defense while attacking."},
"Dominance Ice": {cost:2010, stats:"+70 Physical Defense • +500 Mana • +5% Move Speed", passive:"Arctic Cold: Anti-heal aura."},
"Queen's Wings": {cost:2250, stats:"+900 HP • +40 Adaptive Attack • +10% CDR", passive:"Demonize: Damage reduction on low HP."},
"Thunder Belt": {cost:1820, stats:"+800 HP • +15 Physical Defense • +10% CDR", passive:"Thunderbolt: True damage after skills."},

// MAGIC DEFENSE
"Athena Shield": {cost:2150, stats:"+900 HP • +48 Magic Defense • +2 HP Regen", passive:"Shield: After taking Magic Damage, reduces Magic Damage taken by 25% for 3 seconds. The effect returns 5 seconds after leaving combat."},
"Radiant Armor": {cost:1880, stats:"+800 HP • +52 Magic Defense", passive:"Holy Blessing: Reduces continuous magic damage."},
"Cursed Helmet": {cost:1910, stats:"+1200 HP • +25 Magic Defense", passive:"Burns nearby enemies."},
"Oracle": {cost:1860, stats:"+850 HP • +42 Magic Defense • +10% CDR", passive:"Blessing: Increases shield and healing."},

// HYBRID DEFENSE
"Immortality": {cost:2120, stats:"+800 HP • +20 Physical Defense", passive:"Resurrect once after death."},
"Chastise Pauldron": {cost:2100, stats:"+900 HP • +40 Physical Defense", passive:"Chastise: Taking damage reduces the attacker’s Attack Speed and Attack Speed cap for 2 seconds. Redemption restores 20% Max HP when incoming damage drops you below 30% HP (60s cooldown)."},

// HP / REGEN
"Guardian Helmet": {cost:2500, stats:"+1550 HP", passive:"Recovery: Massive HP regeneration outside combat."},
"Flask of the Oasis": {cost:1850, stats:"+60 Magic Power • +300 HP • +10% CDR", passive:"Blessing: Enhances healing and shields."},

// JUNGLE
"Flame Retribution": {cost:0, stats:"Retribution Upgrade", passive:"Steals Physical/Magic Attack from enemy."},
"Ice Retribution": {cost:0, stats:"Retribution Upgrade", passive:"Slows enemy and steals movement speed."},
"Bloody Retribution": {cost:0, stats:"Retribution Upgrade", passive:"Deals damage and heals you."},

// ROAM
"Conceal": {cost:0, stats:"Roam Blessing", passive:"Team gains camouflage and movement speed."},
"Favor": {cost:0, stats:"Roam Blessing", passive:"Heals nearby allies."},
"Encourage": {cost:0, stats:"Roam Blessing", passive:"Buffs allies' attack speed and damage."},
"Dire Hit": {cost:0, stats:"Roam Blessing", passive:"Extra damage to low HP enemies."}
};

const itemMeta = {
  catalogType: "Core recommended item subset",
  bundledItems: 59,
  currentFullPool: 104,
  source: "MLBBHub item database / Liquipedia dataset",
  verified: "2026-10-16",
  note: "The app intentionally bundles the 59 items used by its offline hero builds rather than pretending to be a complete 104-item shop database. Item costs were refreshed against the current item dataset; hero builds remain curated offline recommendations."
};

window.items = items;
window.details = itemDetails;