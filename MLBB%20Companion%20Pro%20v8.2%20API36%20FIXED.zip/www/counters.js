const counters = {
  "Miya": {
    strong: ["Layla","Hanabi","Ixia"],
    weak: ["Saber","Helcurt","Natalia"]
  },

  "Layla": {
    strong: ["Miya","Hanabi","Bruno"],
    weak: ["Saber","Hayabusa","Natalia"]
  },

  "Hanabi": {
    strong: ["Moskov","Miya","Layla"],
    weak: ["Brody","Saber","Helcurt"]
  },

  "Moskov": {
    strong: ["Melissa","Layla","Bruno"],
    weak: ["Khufra","Natalia","Saber"]
  },

  "Sun": {
    strong: ["Argus","Zilong","Aulus"],
    weak: ["Baxia","Esmeralda","X.Borg"]
  },

  "Argus": {
    strong: ["Yu Zhong","Terizla","Aldous"],
    weak: ["Kaja","Franco","Valir"]
  },

  "Thamuz": {
    strong: ["Alpha","Aulus","Martis"],
    weak: ["Karrie","Esmeralda","Valir"]
  },

  "Alpha": {
    strong: ["Fredrinn","Balmond","Sun"],
    weak: ["Esmeralda","Valir","Karrie"]
  },

  "Saber": {
    strong: ["Miya","Layla","Hanabi"],
    weak: ["Diggie","Lolita","Franco"]
  },

  "Helcurt": {
    strong: ["Miya","Layla","Cecilion"],
    weak: ["Diggie","Khufra","Belerick"]
  },

  "Natalia": {
    strong: ["Layla","Miya","Lesley"],
    weak: ["Belerick","Khufra","Diggie"]
  },

  "Brody": {
    strong: ["Hanabi","Moskov","Miya"],
    weak: ["Lolita","Khufra","Baxia"]
  },

  "Ixia": {
    strong: ["Hanabi","Layla","Bruno"],
    weak: ["Saber","Helcurt","Natalia"]
  },

  "Bruno": {
    strong: ["Layla","Miya","Melissa"],
    weak: ["Khufra","Lolita","Saber"]
  },

  "Melissa": {
    strong: ["Moskov","Hanabi","Claude"],
    weak: ["Natalia","Saber","Lancelot"]
  },
  
  "Beatrix":{
    strong:["Lesley","Bruno","Melissa"],
    weak:["Saber","Natalia","Hayabusa"]
  },

  "Claude":{
    strong:["Belerick","Hylos","Gatotkaca"],
    weak:["Khufra","Natalia","Helcurt"]
  },

  "Clint":{
    strong:["Layla","Lesley","Bruno"],
    weak:["Hayabusa","Saber","Natalia"]
  },

  "Granger":{
    strong:["Melissa","Hanabi","Bruno"],
    weak:["Khufra","Natalia","Helcurt"]
  },

  "Irithel":{
    strong:["Belerick","Hylos","Uranus"],
    weak:["Natalia","Saber","Brody"]
  },

  "Karrie":{
    strong:["Hylos","Belerick","Uranus"],
    weak:["Saber","Hayabusa","Natalia"]
  },

  "Lesley":{
    strong:["Layla","Bruno","Miya"],
    weak:["Natalia","Hayabusa","Saber"]
  },

  "Natan":{
    strong:["Belerick","Hylos","Uranus"],
    weak:["Saber","Helcurt","Natalia"]
  },

  "Popol and Kupa":{
    strong:["Ling","Fanny","Hayabusa"],
    weak:["Atlas","Khufra","Lolita"]
  },

  "Wanwan":{
    strong:["Hylos","Uranus","Belerick"],
    weak:["Khufra","Franco","Saber"]
  },

  "Zilong":{
    strong:["Aldous","Aulus","Sun"],
    weak:["Khaleed","Thamuz","Esmeralda"]
  },

  "X.Borg":{
    strong:["Sun","Alpha","Aulus"],
    weak:["Karrie","Esmeralda","Valir"]
  },

  "Aldous":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Kaja","Franco","Valir"]
  },

  "Aulus":{
    strong:["Sun","Zilong","Balmond"],
    weak:["Thamuz","Esmeralda","Karrie"]
  },

  "Badang":{
    strong:["Zilong","Sun","Argus"],
    weak:["Esmeralda","Valir","Khufra"]
  },
  
  "Balmond":{
    strong:["Sun","Zilong","Aulus"],
    weak:["Karrie","Esmeralda","Valir"]
  },

  "Bane":{
    strong:["Khaleed","Balmond","Terizla"],
    weak:["Esmeralda","Valir","Karrie"]
  },

  "Chou":{
    strong:["Argus","Yu Zhong","Aldous"],
    weak:["Diggie","Valir","Esmeralda"]
  },

  "Dyrroth":{
    strong:["Uranus","Esmeralda","Terizla"],
    weak:["Thamuz","Alpha","Karrie"]
  },

  "Freya":{
    strong:["Sun","Zilong","Aulus"],
    weak:["Esmeralda","Valir","Karrie"]
  },

  "Gatotkaca":{
    strong:["Zilong","Argus","Badang"],
    weak:["Karrie","Valir","Esmeralda"]
  },

  "Guinevere":{
    strong:["Sun","Alpha","Aulus"],
    weak:["Diggie","Valir","Khufra"]
  },

  "Jawhead":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Diggie","Khufra","Esmeralda"]
  },

  "Khaleed":{
    strong:["Zilong","Sun","Aulus"],
    weak:["Esmeralda","Thamuz","Valir"]
  },

  "Leomord":{
    strong:["Argus","Badang","Balmond"],
    weak:["Esmeralda","Karrie","Valir"]
  },

  "Lapu-Lapu":{
    strong:["Badang","Argus","Zilong"],
    weak:["Esmeralda","Thamuz","Karrie"]
  },

  "Martis":{
    strong:["Hayabusa","Ling","Fanny"],
    weak:["Thamuz","Esmeralda","Karrie"]
  },

  "Masha":{
    strong:["Hylos","Belerick","Uranus"],
    weak:["Karrie","Valir","Thamuz"]
  },

  "Minsitthar":{
    strong:["Fanny","Ling","Lancelot"],
    weak:["Valir","Esmeralda","Diggie"]
  },

  "Paquito":{
    strong:["Badang","Argus","Zilong"],
    weak:["Esmeralda","Thamuz","Valir"]
  },
  
  "Phoveus":{
    strong:["Joy","Wanwan","Lancelot"],
    weak:["Valir","Karrie","Esmeralda"]
  },

  "Roger":{
    strong:["Hylos","Belerick","Uranus"],
    weak:["Khufra","Franco","Kaja"]
  },

  "Ruby":{
    strong:["Terizla","Alpha","Balmond"],
    weak:["Valir","Esmeralda","Diggie"]
  },

  "Silvanna":{
    strong:["Sun","Argus","Badang"],
    weak:["Diggie","Valir","Esmeralda"]
  },

  "Terizla":{
    strong:["Zilong","Sun","Argus"],
    weak:["Esmeralda","Karrie","Valir"]
  },

  "Yu Zhong":{
    strong:["Badang","Aulus","Zilong"],
    weak:["Esmeralda","Karrie","Valir"]
  },

  "Julian":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Khufra","Franco","Diggie"]
  },

  "Alice":{
    strong:["Balmond","Terizla","Ruby"],
    weak:["Valir","Karrie","Esmeralda"]
  },

  "Aurora":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Diggie","Valentina","Lunox"]
  },

  "Cecilion":{
    strong:["Terizla","Balmond","Hylos"],
    weak:["Natalia","Saber","Hayabusa"]
  },

  "Chang'e":{
    strong:["Belerick","Hylos","Uranus"],
    weak:["Hayabusa","Natalia","Lancelot"]
  },

  "Cyclops":{
    strong:["Fanny","Ling","Lancelot"],
    weak:["Saber","Natalia","Valentina"]
  },

  "Eudora":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Diggie","Valentina","Lunox"]
  },

  "Faramis":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Valentina","Diggie","Kaja"]
  },

  "Gord":{
    strong:["Terizla","Hylos","Belerick"],
    weak:["Natalia","Hayabusa","Saber"]
  },
  
  "Harith":{
    strong:["Terizla","Belerick","Hylos"],
    weak:["Kaja","Franco","Valentina"]
  },

  "Kadita":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Diggie","Valentina","Lunox"]
  },

  "Kagura":{
    strong:["Gord","Cecilion","Aurora"],
    weak:["Hayabusa","Natalia","Valentina"]
  },

  "Lunox":{
    strong:["Esmeralda","Hylos","Belerick"],
    weak:["Kaja","Natalia","Saber"]
  },

  "Luo Yi":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Hayabusa","Natalia","Valentina"]
  },

  "Lylia":{
    strong:["Balmond","Ruby","Terizla"],
    weak:["Hayabusa","Saber","Natalia"]
  },

  "Novaria":{
    strong:["Franco","Atlas","Tigreal"],
    weak:["Natalia","Ling","Hayabusa"]
  },

  "Odette":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Saber","Hayabusa","Natalia"]
  },

  "Pharsa":{
    strong:["Terizla","Belerick","Hylos"],
    weak:["Natalia","Hayabusa","Ling"]
  },

  "Selena":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Diggie","Khufra","Valentina"]
  },

  "Valentina":{
    strong:["Faramis","Atlas","Tigreal"],
    weak:["Lunox","Kadita","Kaja"]
  },

  "Vale":{
    strong:["Atlas","Tigreal","Belerick"],
    weak:["Hayabusa","Natalia","Ling"]
  },

  "Valir":{
    strong:["Terizla","Yu Zhong","Thamuz"],
    weak:["Lunox","Kadita","Kaja"]
  },

  "Vexana":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Hayabusa","Natalia","Ling"]
  },

  "Xavier":{
    strong:["Hylos","Belerick","Terizla"],
    weak:["Hayabusa","Natalia","Valentina"]
  },
  
  "Zhask":{
    strong:["Hylos","Belerick","Uranus"],
    weak:["Hayabusa","Natalia","Saber"]
  },

  "Yve":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Hayabusa","Natalia","Ling"]
  },

  "Nana":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Valentina","Lunox","Kadita"]
  },

  "Zhuxin":{
    strong:["Atlas","Tigreal","Hylos"],
    weak:["Hayabusa","Natalia","Valentina"]
  },

  "Esmeralda":{
    strong:["Terizla","Yu Zhong","Thamuz"],
    weak:["Karrie","Lunox","Dyrroth"]
  },

  "Aamon":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Khufra","Diggie","Franco"]
  },

  "Benedetta":{
    strong:["Gord","Cecilion","Aurora"],
    weak:["Khufra","Franco","Minsitthar"]
  },

  "Fanny":{
    strong:["Layla","Lesley","Gord"],
    weak:["Khufra","Minsitthar","Kaja"]
  },

  "Hanzo":{
    strong:["Atlas","Tigreal","Hylos"],
    weak:["Natalia","Saber","Hayabusa"]
  },

  "Harley":{
    strong:["Layla","Cecilion","Odette"],
    weak:["Kaja","Diggie","Valentina"]
  },

  "Hayabusa":{
    strong:["Layla","Lesley","Pharsa"],
    weak:["Khufra","Minsitthar","Kaja"]
  },

  "Joy":{
    strong:["Valir","Gord","Aurora"],
    weak:["Phoveus","Minsitthar","Khufra"]
  },

  "Karina":{
    strong:["Gord","Aurora","Eudora"],
    weak:["Kaja","Valentina","Khufra"]
  },

  "Lancelot":{
    strong:["Layla","Lesley","Cecilion"],
    weak:["Khufra","Minsitthar","Kaja"]
  },

  "Ling":{
    strong:["Layla","Lesley","Pharsa"],
    weak:["Khufra","Minsitthar","Kaja"]
  },
  
  "Natalia":{
    strong:["Layla","Lesley","Pharsa"],
    weak:["Belerick","Khufra","Diggie"]
  },

  "Nolan":{
    strong:["Layla","Cecilion","Odette"],
    weak:["Khufra","Minsitthar","Kaja"]
  },

  "Akai":{
    strong:["Ling","Fanny","Lancelot"],
    weak:["Valir","Karrie","Esmeralda"]
  },

  "Atlas":{
    strong:["Layla","Hanabi","Miya"],
    weak:["Diggie","Valentina","Kaja"]
  },

  "Baxia":{
    strong:["Esmeralda","Alice","Harith"],
    weak:["Karrie","Lunox","Dyrroth"]
  },

  "Belerick":{
    strong:["Miya","Moskov","Wanwan"],
    weak:["Valir","Karrie","Lunox"]
  },

  "Carmilla":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Diggie","Valentina","Lunox"]
  },

  "Edith":{
    strong:["Ling","Fanny","Lancelot"],
    weak:["Valir","Karrie","Esmeralda"]
  },

  "Franco":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Diggie","Valentina","Akai"]
  },

  "Gloo":{
    strong:["Badang","Sun","Argus"],
    weak:["Valir","Karrie","Esmeralda"]
  },

  "Hylos":{
    strong:["Ling","Fanny","Hayabusa"],
    weak:["Karrie","Lunox","Dyrroth"]
  },

  "Johnson":{
    strong:["Layla","Hanabi","Miya"],
    weak:["Diggie","Valentina","Kaja"]
  },

  "Khufra":{
    strong:["Fanny","Ling","Lancelot"],
    weak:["Diggie","Valir","Lunox"]
  },

  "Lolita":{
    strong:["Miya","Moskov","Wanwan"],
    weak:["Valir","Esmeralda","Karrie"]
  },

  "Minotaur":{
    strong:["Atlas","Khufra","Tigreal"],
    weak:["Diggie","Valentina","Kaja"]
  },
  
  "Tigreal":{
    strong:["Miya","Layla","Hanabi"],
    weak:["Diggie","Valentina","Kaja"]
  },

  "Uranus":{
    strong:["Terizla","Ruby","Balmond"],
    weak:["Dyrroth","Karrie","Lunox"]
  },

  "Angela":{
    strong:["Aldous","Ling","Fanny"],
    weak:["Kaja","Valentina","Franco"]
  },

  "Chip":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Diggie","Valentina","Kaja"]
  },

  "Diggie":{
    strong:["Atlas","Tigreal","Khufra"],
    weak:["Natalia","Helcurt","Saber"]
  },

  "Estes":{
    strong:["Balmond","Terizla","Alpha"],
    weak:["Baxia","Kaja","Valentina"]
  },

  "Floryn":{
    strong:["Alpha","Balmond","Ruby"],
    weak:["Baxia","Kaja","Valentina"]
  },

  "Kalea":{
    strong:["Fanny","Ling","Lancelot"],
    weak:["Diggie","Valentina","Esmeralda"]
  },

  "Kaja":{
    strong:["Fanny","Ling","Hayabusa"],
    weak:["Diggie","Valentina","Lunox"]
  },

  "Mathilda":{
    strong:["Gord","Cecilion","Pharsa"],
    weak:["Khufra","Diggie","Kaja"]
  },

  "Rafaela":{
    strong:["Alpha","Balmond","Terizla"],
    weak:["Baxia","Kaja","Valentina"]
  },

  "Kimmy": { strong:["Layla","Bruno","Ixia"], weak:["Lolita","Khufra","Natalia"] },

  // Complete roster matchup coverage added in v4.5
  "Alucard": {"strong":["Natalia","Sun","Saber"],"weak":["Khufra","Barats","Fredrinn"]},
  "Arlott": {"strong":["Zhuxin","Nolan","Natan"],"weak":["Phoveus","Zhask","Argus"]},
  "Barats": {"strong":["Silvanna","Alucard","Argus"],"weak":["X.Borg","Gord","Yve"]},
  "Cici": {"strong":["Terizla","Balmond","Gatotkaca"],"weak":["Phoveus","Karrie","Valir"]},
  "Fredrinn": {"strong":["Saber","Aamon","Alucard"],"weak":["Karrie","Valir","Lunox"]},
  "Grock": {"strong":["Odette","Brody","Diggie"],"weak":["Alice","Esmeralda","Marcel"]},
  "Gusion": {"strong":["Aamon","Suyou","Cecilion"],"weak":["Lolita","Khufra","Roger"]},
  "Hilda": {"strong":["Fanny","Faramis","Layla"],"weak":["Karrie","Valir","Esmeralda"]},
  "Hirara": {"strong":["Layla","Cecilion","Eudora"],"weak":["Khufra","Lolita","Saber"]},
  "Lukas": {"strong":["Layla","Eudora","Gord"],"weak":["Karrie","Valir","Phoveus"]},
  "Marcel": {"strong":["Odette","Brody","Grock"],"weak":["Kaja","Valir","Diggie"]},
  "Obsidia": {"strong":["Miya","Layla","Bruno"],"weak":["Saber","Natalia","Helcurt"]},
  "Sora": {"strong":["Natan","Zhuxin","Gord"],"weak":["Phoveus","Karrie","Valir"]},
  "Suyou": {"strong":["Aamon","Nolan","Fanny"],"weak":["Khufra","Saber","Lolita"]},
  "Yi Sun-shin": {"strong":["Fanny","Saber","Nolan"],"weak":["Khufra","Lolita","Natalia"]},
  "Yin": {"strong":["Layla","Eudora","Cecilion"],"weak":["Valir","Karrie","Khufra"]},
  "Zetian": {"strong":["Saber","Natalia","Lancelot"],"weak":["Lolita","Khufra","Gusion"]},
};
