const builds = {
	"Miya":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Windtalker","Malefic Gun"]
  },

  "Layla":{
    spell:"Flicker", emblem:"Marksman",
    build:["Swift Boots","Berserker's Fury","Windtalker","Haas Claws","Malefic Gun","Blade of Despair"]
  },

  "Hanabi":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Rose Gold Meteor","Malefic Gun"]
  },

  "Moskov":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Malefic Gun","Rose Gold Meteor"]
  },

  "Claude":{
    spell:"Vengeance", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Windtalker","Malefic Gun"]
  },

  "Brody":{
    spell:"Flicker", emblem:"Marksman",
    build:["Warrior Boots","Blade of the Heptaseas","Hunter Strike","Malefic Roar","Blade of Despair","Immortality"]
  },

  "Beatrix":{
    spell:"Flicker", emblem:"Marksman",
    build:["Swift Boots","Hunter Strike","Blade of Despair","Malefic Roar","Sea Halberd","Rose Gold Meteor"]
  },

  "Bruno":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Berserker's Fury","Haas Claws","Malefic Gun","Blade of Despair","Windtalker"]
  },

  "Clint":{
    spell:"Flicker", emblem:"Marksman",
    build:["Magic Shoes","Endless Battle","Hunter Strike","Malefic Roar","Blade of Despair","Immortality"]
  },

  "Granger":{
    spell:"Flicker", emblem:"Marksman",
    build:["Magic Shoes","Hunter Strike","Blade of Despair","Malefic Roar","Endless Battle","Immortality"]
  },

  "Irithel":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Windtalker","Malefic Gun"]
  },

  "Karrie":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Thunder Belt","Malefic Gun"]
  },

  "Lesley":{
    spell:"Flicker", emblem:"Marksman",
    build:["Swift Boots","Berserker's Fury","Endless Battle","Malefic Roar","Blade of Despair","Rose Gold Meteor"]
  },

  "Melissa":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Windtalker","Malefic Gun"]
  },

  "Natan":{
    spell:"Inspire", emblem:"Marksman",
    build:["Arcane Boots","Feather of Heaven","Golden Staff","Starlium Scythe","Holy Crystal","Blood Wings"]
  },

  "Popol and Kupa":{
    spell:"Flicker", emblem:"Marksman",
    build:["Swift Boots","Endless Battle","Hunter Strike","Malefic Roar","Blade of Despair","Immortality"]
  },

  "Wanwan":{
    spell:"Inspire", emblem:"Marksman",
    build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Windtalker","Malefic Gun"]
  },

  "Kimmy":{
    spell:"Sprint", emblem:"Marksman",
    build:["Arcane Boots","Genius Wand","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Edith":{
    spell:"Vengeance", emblem:"Tank",
    build:["Warrior Boots","Thunder Belt","Dominance Ice","Athena Shield","Blade Armor","Immortality"]
  },
  
  "Argus":{
    spell:"Inspire", emblem:"Fighter",
    build:["War Axe","Sea Halberd","Demon Hunter Sword","Malefic Roar","Immortality","Athena Shield"]
  },

  "Alpha":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Queen's Wings","Oracle","Blade of Despair","Immortality"]
  },

  "Thamuz":{
    spell:"Vengeance", emblem:"Fighter",
    build:["Warrior Boots","Corrosion Scythe","Demon Hunter Sword","Brute Force Breastplate","Oracle","Immortality"]
  },

  "Sun":{
    spell:"Inspire", emblem:"Fighter",
    build:["Swift Boots","Corrosion Scythe","Demon Hunter Sword","Golden Staff","Malefic Roar","Immortality"]
  },

  "Zilong":{
    spell:"Inspire", emblem:"Assassin",
    build:["Swift Boots","Berserker's Fury","Windtalker","Blade of Despair","Malefic Roar","Immortality"]
  },

  "X.Borg":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","War Axe","Immortality","Oracle","Brute Force Breastplate","Hunter Strike"]
  },

  "Aldous":{
    spell:"Flicker", emblem:"Fighter",
    build:["Tough Boots","Endless Battle","Thunder Belt","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Aulus":{
    spell:"Inspire", emblem:"Fighter",
    build:["War Axe","Corrosion Scythe","Demon Hunter Sword","Malefic Roar","Oracle","Immortality"]
  },

  "Badang":{
    spell:"Flicker", emblem:"Fighter",
    build:["Swift Boots","Golden Staff","Demon Hunter Sword","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Balmond":{
    spell:"Retribution", emblem:"Fighter",
    build:["Warrior Boots","War Axe","Brute Force Breastplate","Oracle","Guardian Helmet","Immortality"]
  },

  "Bane":{
    spell:"Flicker", emblem:"Fighter",
    build:["Magic Shoes","Endless Battle","Hunter Strike","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Chou":{
    spell:"Flicker", emblem:"Fighter",
    build:["Tough Boots","Hunter Strike","Blade of the Heptaseas","Malefic Roar","Blade of Despair","Immortality"]
  },

  "Dyrroth":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Queen's Wings","Immortality"]
  },

  "Freya":{
    spell:"Inspire", emblem:"Fighter",
    build:["Swift Boots","War Axe","Golden Staff","Demon Hunter Sword","Blade of Despair","Immortality"]
  },

  "Gatotkaca":{
    spell:"Vengeance", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Athena Shield","Oracle","Immortality"]
  },

  "Guinevere":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Jawhead":{
    spell:"Flicker", emblem:"Fighter",
    build:["Warrior Boots","Hunter Strike","Blade of Despair","Malefic Roar","Brute Force Breastplate","Immortality"]
  },

  "Khaleed":{
    spell:"Flicker", emblem:"Fighter",
    build:["Warrior Boots","War Axe","Hunter Strike","Queen's Wings","Oracle","Immortality"]
  },

  "Leomord":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Oracle","Immortality"]
  },

  "Lapu-Lapu":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Queen's Wings","Oracle","Blade of Despair","Immortality"]
  },

  "Martis":{
    spell:"Retribution", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Brute Force Breastplate","Blade of Despair","Oracle","Immortality"]
  },

  "Masha":{
    spell:"Sprint", emblem:"Fighter",
    build:["Swift Boots","Corrosion Scythe","Demon Hunter Sword","Golden Staff","Malefic Roar","Immortality"]
  },

  "Minsitthar":{
    spell:"Flicker", emblem:"Fighter",
    build:["Warrior Boots","Thunder Belt","Hunter Strike","Blade of Despair","Oracle","Immortality"]
  },

  "Paquito":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Blade of the Heptaseas","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Phoveus":{
    spell:"Vengeance", emblem:"Fighter",
    build:["Tough Boots","Thunder Belt","Oracle","Athena Shield","Queen's Wings","Immortality"]
  },

  "Roger":{
    spell:"Retribution", emblem:"Marksman",
    build:["Swift Boots","War Axe","Demon Hunter Sword","Malefic Gun","Blade of Despair","Immortality"]
  },

  "Ruby":{
    spell:"Flicker", emblem:"Fighter",
    build:["Warrior Boots","War Axe","Queen's Wings","Oracle","Thunder Belt","Immortality"]
  },

  "Silvanna":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Holy Crystal","Divine Glaive","Oracle","Winter Crown"]
  },

  "Terizla":{
    spell:"Vengeance", emblem:"Fighter",
    build:["Warrior Boots","War Axe","Thunder Belt","Oracle","Queen's Wings","Immortality"]
  },

  "Yu Zhong":{
    spell:"Flicker", emblem:"Fighter",
    build:["War Axe","Hunter Strike","Queen's Wings","Oracle","Blade of Despair","Immortality"]
  },

  "Julian":{
    spell:"Retribution", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Starlium Scythe","Holy Crystal","Divine Glaive","Blood Wings"]
  },
  
  "Alice":{
    spell:"Flicker", emblem:"Mage",
    build:["Tough Boots","Clock of Destiny","Lightning Truncheon","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Aurora":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Cecilion":{
    spell:"Flicker", emblem:"Mage",
    build:["Magic Shoes","Clock of Destiny","Lightning Truncheon","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Chang'e":{
    spell:"Sprint", emblem:"Mage",
    build:["Magic Shoes","Glowing Wand","Genius Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Cyclops":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Starlium Scythe","Concentrated Energy","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Eudora":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Lightning Truncheon","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Faramis":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Glowing Wand","Oracle","Holy Crystal","Divine Glaive","Immortality"]
  },

  "Gord":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Harith":{
    spell:"Purify", emblem:"Mage",
    build:["Magic Shoes","Starlium Scythe","Feather of Heaven","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Kadita":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Kagura":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Lightning Truncheon","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Lunox":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Clock of Destiny","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Luo Yi":{
    spell:"Flicker", emblem:"Mage",
    build:["Magic Shoes","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Lylia":{
    spell:"Sprint", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Genius Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Novaria":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Odette":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Clock of Destiny","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Pharsa":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Selena":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Valentina":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Vale":{
    spell:"Flameshot", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Valir":{
    spell:"Sprint", emblem:"Mage",
    build:["Magic Shoes","Glowing Wand","Ice Queen Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Vexana":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Clock of Destiny","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Xavier":{
    spell:"Flameshot", emblem:"Mage",
    build:["Magic Shoes","Clock of Destiny","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Zhask":{
    spell:"Inspire", emblem:"Mage",
    build:["Arcane Boots","Feather of Heaven","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Yve":{
    spell:"Sprint", emblem:"Mage",
    build:["Magic Shoes","Glowing Wand","Ice Queen Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Nana":{
    spell:"Flameshot", emblem:"Mage",
    build:["Magic Shoes","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Zhuxin":{
    spell:"Flicker", emblem:"Mage",
    build:["Arcane Boots","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Esmeralda":{
    spell:"Flicker", emblem:"Mage",
    build:["Tough Boots","Starlium Scythe","Oracle","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Aamon":{
    spell:"Retribution", emblem:"Assassin",
    build:["Arcane Boots","Genius Wand","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Benedetta":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Queen's Wings","Immortality"]
  },

  "Fanny":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Queen's Wings","Immortality"]
  },

  "Hanzo":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Corrosion Scythe","Demon Hunter Sword","Malefic Roar","Blade of Despair","Immortality"]
  },

  "Harley":{
    spell:"Retribution", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Hayabusa":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Endless Battle","Immortality"]
  },

  "Helcurt":{
    spell:"Retribution", emblem:"Assassin",
    build:["Swift Boots","Hunter Strike","Blade of Despair","Malefic Roar","Rose Gold Meteor","Immortality"]
  },

  "Joy":{
    spell:"Retribution", emblem:"Assassin",
    build:["Arcane Boots","Starlium Scythe","Holy Crystal","Divine Glaive","Blood Wings","Winter Crown"]
  },

  "Karina":{
    spell:"Retribution", emblem:"Mage",
    build:["Arcane Boots","Genius Wand","Starlium Scythe","Holy Crystal","Divine Glaive","Blood Wings"]
  },

  "Lancelot":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Endless Battle","Immortality"]
  },

  "Ling":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Endless Battle","Immortality"]
  },

  "Natalia":{
    spell:"Execute", emblem:"Assassin",
    build:["Swift Boots","Blade of the Heptaseas","Hunter Strike","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Nolan":{
    spell:"Retribution", emblem:"Assassin",
    build:["War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Endless Battle","Immortality"]
  },

  "Saber":{
    spell:"Execute", emblem:"Assassin",
    build:["Magic Shoes","Blade of the Heptaseas","Hunter Strike","Blade of Despair","Malefic Roar","Immortality"]
  },

  "Akai":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Atlas":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Dominance Ice","Thunder Belt","Oracle","Athena Shield","Immortality"]
  },

  "Baxia":{
    spell:"Retribution", emblem:"Tank",
    build:["Tough Boots","Cursed Helmet","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Belerick":{
    spell:"Vengeance", emblem:"Tank",
    build:["Warrior Boots","Cursed Helmet","Blade Armor","Dominance Ice","Oracle","Immortality"]
  },

  "Franco":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Gloo":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Cursed Helmet","Dominance Ice","Oracle","Guardian Helmet","Immortality"]
  },

  "Hylos":{
    spell:"Vengeance", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Guardian Helmet","Immortality"]
  },

  "Johnson":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Khufra":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Lolita":{
    spell:"Flicker", emblem:"Tank",
    build:["Warrior Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Minotaur":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Guardian Helmet","Immortality"]
  },

  "Tigreal":{
    spell:"Flicker", emblem:"Tank",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Uranus":{
    spell:"Sprint", emblem:"Tank",
    build:["Warrior Boots","Thunder Belt","Oracle","Guardian Helmet","Athena Shield","Immortality"]
  },

  "Angela":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Oracle","Dominance Ice","Fleeting Time","Immortality","Athena Shield"]
  },

  "Chip":{
    spell:"Flicker", emblem:"Support",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Diggie":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Fleeting Time","Oracle","Dominance Ice","Athena Shield","Immortality"]
  },

  "Estes":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Oracle","Fleeting Time","Dominance Ice","Athena Shield","Immortality"]
  },

  "Floryn":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Oracle","Fleeting Time","Dominance Ice","Athena Shield","Immortality"]
  },

  "Kalea":{
    spell:"Flicker", emblem:"Support",
    build:["Tough Boots","Thunder Belt","Oracle","Dominance Ice","Athena Shield","Immortality"]
  },

  "Kaja":{
    spell:"Flicker", emblem:"Support",
    build:["Tough Boots","Thunder Belt","Dominance Ice","Oracle","Athena Shield","Immortality"]
  },

  "Mathilda":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Oracle","Fleeting Time","Dominance Ice","Athena Shield","Immortality"]
  },

  "Rafaela":{
    spell:"Flicker", emblem:"Support",
    build:["Magic Shoes","Oracle","Fleeting Time","Dominance Ice","Athena Shield","Immortality"]
  },

  // Complete roster build coverage added in v4.5
  "Alucard":{ spell:"Flame Retribution", emblem:"Assassin", build:["Tough Boots","War Axe","Hunter Strike","Endless Battle","Blade of Despair","Immortality"] },
  "Arlott":{ spell:"Flicker", emblem:"Fighter", build:["Tough Boots","War Axe","Hunter Strike","Queen's Wings","Oracle","Immortality"] },
  "Barats":{ spell:"Bloody Retribution", emblem:"Tank", build:["Tough Boots","Thunder Belt","Cursed Helmet","Dominance Ice","Radiant Armor","Immortality"] },
  "Carmilla":{ spell:"Flicker", emblem:"Tank", build:["Tough Boots","Dominance Ice","Oracle","Radiant Armor","Fleeting Time","Immortality"] },
  "Cici":{ spell:"Flicker", emblem:"Fighter", build:["Tough Boots","War Axe","Brute Force Breastplate","Queen's Wings","Oracle","Immortality"] },
  "Fredrinn":{ spell:"Bloody Retribution", emblem:"Tank", build:["Tough Boots","Thunder Belt","Dominance Ice","Guardian Helmet","Radiant Armor","Immortality"] },
  "Grock":{ spell:"Flicker", emblem:"Tank", build:["Tough Boots","Thunder Belt","Dominance Ice","Antique Cuirass","Radiant Armor","Immortality"] },
  "Gusion":{ spell:"Flame Retribution", emblem:"Assassin", build:["Arcane Boots","Genius Wand","Glowing Wand","Divine Glaive","Holy Crystal","Blood Wings"] },
  "Hilda":{ spell:"Flicker", emblem:"Fighter", build:["Warrior Boots","Thunder Belt","War Axe","Hunter Strike","Oracle","Immortality"] },
  "Hirara":{ spell:"Flame Retribution", emblem:"Assassin", build:["Arcane Boots","Genius Wand","Glowing Wand","Divine Glaive","Holy Crystal","Blood Wings"] },
  "Ixia":{ spell:"Inspire", emblem:"Marksman", build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Malefic Gun","Windtalker"] },
  "Lukas":{ spell:"Flicker", emblem:"Fighter", build:["Tough Boots","War Axe","Hunter Strike","Queen's Wings","Oracle","Immortality"] },
  "Marcel":{ spell:"Flicker", emblem:"Support", build:["Tough Boots","Flask of the Oasis","Dominance Ice","Oracle","Fleeting Time","Immortality"] },
  "Obsidia":{ spell:"Inspire", emblem:"Marksman", build:["Swift Boots","Corrosion Scythe","Golden Staff","Demon Hunter Sword","Malefic Gun","Windtalker"] },
  "Sora":{ spell:"Flicker", emblem:"Fighter", build:["Tough Boots","War Axe","Hunter Strike","Queen's Wings","Oracle","Immortality"] },
  "Suyou":{ spell:"Flame Retribution", emblem:"Assassin", build:["Tough Boots","War Axe","Hunter Strike","Blade of Despair","Malefic Roar","Immortality"] },
  "Yi Sun-shin":{ spell:"Flame Retribution", emblem:"Assassin", build:["Warrior Boots","Hunter Strike","Endless Battle","Blade of Despair","Malefic Roar","Immortality"] },
  "Yin":{ spell:"Flicker", emblem:"Assassin", build:["Warrior Boots","War Axe","Hunter Strike","Endless Battle","Blade of Despair","Immortality"] },
  "Zetian":{ spell:"Flicker", emblem:"Mage", build:["Arcane Boots","Genius Wand","Glowing Wand","Holy Crystal","Divine Glaive","Blood Wings"] },
};
