const grid = document.getElementById("heroGrid");
const search = document.getElementById("search");

let currentItemCategory = "All";
let currentView = "heroes";
let currentTierRole = "All";

/* ---------- Asset helpers ---------- */

function heroAsset(name) {
  return `assets/heroes/${name.toLowerCase().replace(/ /g, "-")}.png`;
}

function itemAsset(name) {
  return `assets/items/${name.toLowerCase().replace(/ /g, "_").replace(/'/g, "")}.png`;
}

function jsArg(value) {
  return JSON.stringify(value);
}

/* ---------- Heroes ---------- */

function showHeroes(list) {
  currentView = "heroes";
  search.placeholder = "Search Hero...";
  grid.innerHTML = list.map(hero => `
    <div class="hero" onclick='heroPage(${jsArg(hero.name)})'>
      <img class="heroImg"
           src="${heroAsset(hero.name)}"
           alt="${hero.name}"
           onerror="this.style.display='none'">

      <h3>${hero.name}</h3>

      <div class="cardBadges">
        <span class="badge tierBadge">
          ${tierValue(hero.name)}
        </span>

        <span class="badge role-${
          hero.role.includes("Gold") ? "gold" :
          hero.role.includes("EXP") ? "exp" :
          hero.role.includes("Mid") ? "mid" :
          hero.role.includes("Jungle") ? "jungle" : "roam"
        }">
          ${hero.role.split(" • ")[0]}
        </span>

        <span class="badge diff-${hero.difficulty.toLowerCase()}">
          ${hero.difficulty}
        </span>
      </div>
    </div>
  `).join("");
}

showHeroes(heroes);

function filterRole(role) {
  currentView = "heroes";
  showHeroes(heroes.filter(hero => hero.role.includes(role)));
}

function heroAdvice(h, build, countersData) {
  const role = h.role || "";
  const lowerRole = role.toLowerCase();
  const primary = lowerRole.includes("gold") ? "Gold Lane" :
                  lowerRole.includes("jungle") ? "Jungle" :
                  lowerRole.includes("mid") ? "Mid Lane" :
                  lowerRole.includes("exp") ? "EXP Lane" :
                  lowerRole.includes("roam") ? "Roam" : "Flexible";

  const tips = {
    "Gold Lane": [
      "Prioritize safe farm before forcing fights.",
      "Track missing enemies before stepping past the river.",
      "Use your strongest damage window to convert pressure into objectives."
    ],
    "EXP Lane": [
      "Manage the wave before leaving lane for a fight.",
      "Look for trades that preserve your ability to re-engage.",
      "Turn side-lane pressure into objectives rather than chasing kills."
    ],
    "Mid Lane": [
      "Clear the wave efficiently, then look for the next useful rotation.",
      "Keep vision in mind before moving into river fights.",
      "Save important control or mobility tools for decisive moments."
    ],
    "Jungle": [
      "Plan your route around farm, objectives and likely enemy pressure.",
      "Avoid wasting time on low-percentage ganks.",
      "After a successful play, convert the advantage into an objective or invade."
    ],
    "Roam": [
      "Your value comes from creating space and enabling teammates.",
      "Move with purpose instead of permanently sitting in one lane.",
      "Protect the team's win condition when objectives are about to spawn."
    ],
    "Flexible": [
      "Play around the role selected for the match rather than forcing one pattern.",
      "Prioritize farm and positioning before low-percentage fights.",
      "Convert successful fights into objectives whenever possible."
    ]
  };

  return { primary, tips: tips[primary] };
}

function matchupStatus(heroName, enemyName, countersData) {
  if (!enemyName) return null;
  const data = countersData || { strong: [], weak: [] };
  if (data.weak.includes(enemyName)) {
    return {
      title: "⚠️ Difficult matchup",
      className: "matchupDanger",
      text: `${enemyName} is listed as a threat for ${heroName}. Prioritize safe positioning and avoid unnecessary fights.`
    };
  }
  if (data.strong.includes(enemyName)) {
    return {
      title: "✅ Favorable matchup",
      className: "matchupGood",
      text: `${heroName} is listed as strong against ${enemyName}. Use the matchup advantage to create lane or map pressure.`
    };
  }

  // Also check the enemy's matchup list. This gives us useful pairwise
  // intelligence even when the current hero does not explicitly list the enemy.
  const enemyData = counters[enemyName] || { strong: [], weak: [] };
  if (enemyData.weak.includes(heroName)) {
    return {
      title: "✅ Favorable matchup",
      className: "matchupGood",
      text: `${enemyName} is listed as weak against ${heroName}. Use the matchup advantage to create pressure.`
    };
  }
  if (enemyData.strong.includes(heroName)) {
    return {
      title: "⚠️ Difficult matchup",
      className: "matchupDanger",
      text: `${enemyName} is listed as strong against ${heroName}. Play safely, respect their power window and avoid unnecessary fights.`
    };
  }

  // If neither side stores a direct counter edge, still give the player a
  // useful matchup read based on the enemy's archetype instead of saying
  // the matchup is missing. This keeps every hero-vs-hero selection useful.
  const enemyHero = heroes.find(x => x.name === enemyName);
  const enemyRole = (enemyHero?.role || "").toLowerCase();
  let advice = "Play the matchup around your win condition, wave state and objective timing.";

  if (enemyRole.includes("assassin")) {
    advice = "Respect burst and flank angles. Track the enemy assassin before overextending and keep your escape/control tool available.";
  } else if (enemyRole.includes("marksman")) {
    advice = "Respect range and sustained damage. Trade around cooldowns, use cover and avoid taking long open-field fights without an advantage.";
  } else if (enemyRole.includes("mage")) {
    advice = "Respect burst and crowd control. Avoid predictable approaches, watch key cooldowns and punish after their main spell rotation.";
  } else if (enemyRole.includes("fighter")) {
    advice = "Respect their sustained damage and engage range. Keep spacing, punish missed abilities and avoid extended trades on their terms.";
  } else if (enemyRole.includes("tank")) {
    advice = "Do not waste your full burst on the frontline. Play around their engage tools and look for the enemy backline or objective setup.";
  } else if (enemyRole.includes("support")) {
    advice = "Track their peel and control tools. Pressure their positioning and avoid committing before their key defensive ability is used.";
  }

  return {
    title: "➖ Situational matchup",
    className: "matchupNeutral",
    text: `${enemyName} has no direct stored counter edge over ${heroName}. ${advice}`
  };
}

function analyzeHeroMatchup() {
  const heroName = document.getElementById("heroMatchup")?.dataset.hero;
  const enemyName = document.getElementById("heroMatchup")?.value;
  const result = document.getElementById("heroMatchupResult");
  if (!heroName || !result) return;

  const h = heroes.find(x => x.name === heroName);
  const c = counters[heroName] || { strong: [], weak: [] };
  const status = matchupStatus(heroName, enemyName, c);

  if (!enemyName || !status) {
    result.innerHTML = `<p class="muted">Select an enemy hero to analyze the matchup.</p>`;
    return;
  }

  result.innerHTML = `
    <div class="matchupCard ${status.className}">
      <h3>${status.title}</h3>
      <p>${status.text}</p>
      <button class="actionBtn smallBtn" onclick='heroPage(${jsArg(enemyName)})'>View ${enemyName}</button>
    </div>
  `;
}

function baseHeroPageV53(name) {
  const h = heroes.find(x => x.name === name);

  if (!h) {
    showHeroes(heroes);
    return;
  }

  const b = builds[name] || {
    spell: "Not set",
    emblem: "Not set",
    build: []
  };

  const c = counters[name] || {
    strong: [],
    weak: []
  };

  const s = synergy[name] || [];
  const advice = heroAdvice(h, b, c);
  const buildCount = b.build.length;
  const patchAlert = (typeof patchMeta !== "undefined" && patchMeta.changes.some(x => x.toLowerCase().startsWith(name.toLowerCase() + " ")))
    ? `<div class="patchAlert"><strong>Latest patch note:</strong> ${patchMeta.changes.find(x => x.toLowerCase().startsWith(name.toLowerCase() + " "))}</div>` : "";
  const buildPercent = Math.round((buildCount / 6) * 100);

  grid.innerHTML = `
    <div class="heroProfile">
      <div class="profileTop heroProfileTop">
        <img class="profileHeroImg"
             src="${heroAsset(h.name)}"
             alt="${h.name}"
             onerror="this.style.display='none'">

        <div class="heroProfileHeading">
          <div class="eyebrow">HERO INTELLIGENCE</div>
          <h1>${h.name}</h1>
          <div class="badge">${h.role}</div>
          <p><b>Difficulty:</b> ${h.difficulty} &nbsp; <b>Primary:</b> ${advice.primary}</p>
          <p><b>Meta tier:</b> <span class="badge tierBadge">${tierValue(h.name)}</span> <span class="muted">offline ${typeof tierMeta !== "undefined" ? tierMeta.patch : "snapshot"} snapshot</span></p>
        </div>
      </div>

      <div class="heroQuickStats">
        <div class="quickStat"><span>⚡ Spell</span><strong>${b.spell}</strong></div>
        <div class="quickStat"><span>🛡️ Emblem</span><strong>${b.emblem}</strong></div>
        <div class="quickStat"><span>🧱 Build</span><strong>${buildCount}/6</strong><small>${buildPercent}% complete</small></div>
        <div class="quickStat"><span>⚔️ Threats</span><strong>${c.weak.length}</strong><small>stored matchups</small></div>
      </div>

      ${patchAlert}

      <div class="info">
        <section class="intelSection">
          <div class="sectionHeading">
            <div><span class="sectionKicker">RECOMMENDED LOADOUT</span><h3>Battle Setup</h3></div>
          </div>
          <div class="setupGrid">
            <div class="setupCard"><span>Battle Spell</span><strong>${b.spell}</strong></div>
            <div class="setupCard"><span>Emblem</span><strong>${b.emblem}</strong></div>
          </div>
        </section>

        <section class="intelSection">
          <div class="sectionHeading">
            <div><span class="sectionKicker">CORE ITEMS</span><h3>Best Build</h3></div>
            <span class="buildProgress">${buildCount}/6 slots</span>
          </div>
          ${
            b.build.length
              ? `<div class="itemBuild heroBuild">
                  ${b.build.map((item, index) => `
                    <div class="buildItem buildItemNumbered"
                         onclick='itemPage(${jsArg(item)})'>
                      <span class="buildNumber">${index + 1}</span>
                      <img class="itemImg"
                           src="${itemAsset(item)}"
                           alt="${item}"
                           onerror="this.style.display='none'">
                      <p>${item}</p>
                    </div>
                  `).join("")}
                </div>`
              : `<p class="muted">Build data not added yet.</p>`
          }
        </section>

        <section class="intelSection">
          <div class="sectionHeading"><div><span class="sectionKicker">HOW TO PLAY</span><h3>Quick Game Plan</h3></div></div>
          <div class="tipGrid">
            ${advice.tips.map((tip, i) => `
              <div class="tipCard"><span>${i + 1}</span><p>${tip}</p></div>
            `).join("")}
          </div>
        </section>

        <section class="intelSection matchupPlanner">
          <div class="sectionHeading"><div><span class="sectionKicker">MATCHUP CHECK</span><h3>Who are you facing?</h3></div></div>
          <div class="matchupControls">
            <div class="fastHeroPicker heroMatchupPicker">
              <label class="pickerLabel" for="heroMatchup">🔎 Search enemy hero</label>
              <input class="heroSearch heroMatchupSearch" id="heroMatchup" data-hero="${h.name}" type="search" placeholder="Type 1–2 letters or the hero name..." autocomplete="off" onfocus="renderHeroSuggestions(this, 'heroMatchup', 'heroMatchupSuggestions')" oninput="renderHeroSuggestions(this, 'heroMatchup', 'heroMatchupSuggestions')" onkeydown="handleHeroSearchKey(event, this, 'heroMatchup', 'hero')">
              <div class="pickerHint">Type to search • tap a hero • or press Enter</div>
              <div id="heroMatchupSuggestions" class="heroSuggestions"></div>
            </div>
          </div>
          <div id="heroMatchupResult"><p class="muted">Select an enemy hero to analyze the matchup.</p></div>
        </section>

        <section class="intelSection splitSection">
          <div>
            <span class="sectionKicker">MATCHUPS</span>
            <h3>Strong Against</h3>
            <div class="tagWrap">
              ${c.strong.length ? c.strong.map(enemy => `<span class="itemTag clickable goodTag" onclick='heroPage(${jsArg(enemy)})'>${enemy}</span>`).join("") : `<span class="muted">No data yet.</span>`}
            </div>
          </div>
          <div>
            <span class="sectionKicker">MATCHUPS</span>
            <h3>Weak Against</h3>
            <div class="tagWrap">
              ${c.weak.length ? c.weak.map(enemy => `<span class="itemTag clickable dangerTag" onclick='heroPage(${jsArg(enemy)})'>${enemy}</span>`).join("") : `<span class="muted">No data yet.</span>`}
            </div>
          </div>
        </section>

        <section class="intelSection">
          <div class="sectionHeading"><div><span class="sectionKicker">TEAMPLAY</span><h3>Best Team Synergy</h3></div></div>
          <div class="tagWrap">
            ${s.length ? s.map(ally => `<span class="itemTag clickable" onclick='heroPage(${jsArg(ally)})'>${ally}</span>`).join("") : `<span class="muted">No synergy data yet.</span>`}
          </div>
        </section>

        <div class="heroPageActions">
          <button class="backBtn" onclick="showHeroes(heroes)">⬅ Back to Heroes</button>
          <button class="actionBtn" onclick='counterPage(); setTimeout(()=>{const s=document.getElementById("enemyHero"); if(s) s.value=${jsArg(h.name)}; showCounter();},0)'>⚔ Find Counters</button>
        </div>
      </div>
    </div>
  `;
}

search.addEventListener("input", e => {
  const value = e.target.value.toLowerCase().trim();

  if (currentView === "tier") {
    renderTierList(currentTierRole, value);
    return;
  }

  showHeroes(
    heroes.filter(h => h.name.toLowerCase().includes(value))
  );
});

function comingSoon(page) {
  alert(page + " is coming in the next update! 🚀");
}

/* ---------- Data Trust / Provenance ---------- */

function dataPage(){
  currentView='data';
  search.value='';
  search.placeholder='Data & Sources';
  const tm = typeof tierMeta !== 'undefined' ? tierMeta : {};
  const pm = typeof patchMeta !== 'undefined' ? patchMeta : {patch:'local',changes:[]};
  const im = typeof itemMeta !== 'undefined' ? itemMeta : {bundledItems:items.length,currentFullPool:'—'};
  grid.innerHTML = `
    <div class="pagePanel dataTrustPage">
      <div class="sectionHeading">
        <div><span class="sectionKicker">DATA TRUST & PROVENANCE</span><h2>📚 What is real, and what is curated?</h2></div>
        <span class="badge">OFFLINE</span>
      </div>
      <p class="muted">This page is intentionally explicit: the Companion separates measured game statistics from strategy recommendations so it never presents our editorial intelligence as official Moonton data.</p>

      <div class="dataTrustGrid">
        <div class="dataTrustCard"><strong>133</strong><span>Heroes bundled</span><small>Roster completeness checked</small></div>
        <div class="dataTrustCard"><strong>${tm.patch||'—'}</strong><span>Tier snapshot</span><small>${tm.updated||'—'} • ${tm.source||'—'}</small></div>
        <div class="dataTrustCard"><strong>${im.bundledItems}</strong><span>Core items bundled</span><small>Current full item pool: ${im.currentFullPool}</small></div>
        <div class="dataTrustCard"><strong>OFFLINE</strong><span>Draft intelligence</span><small>Uses local heuristics + curated matchup data</small></div>
      </div>

      <section class="intelSection">
        <div class="sectionHeading"><div><span class="sectionKicker">AUTHENTIC / MEASURED</span><h3>Ranked & patch evidence</h3></div></div>
        <ul class="dataList">
          <li><b>Hero roster:</b> 133 heroes in the current data pack.</li>
          <li><b>Tier snapshot:</b> ${tm.source||'MLBBHub'} for Patch ${tm.patch||'—'}, updated ${tm.updated||'—'}.</li>
          <li><b>Official stats cross-check:</b> Moonton Hero Ranking, observed ${tm.officialStatsObserved||'—'}.</li>
          <li><b>Secondary stats cross-check:</b> ${tm.secondaryCheck||'—'}.</li>
          <li><b>Latest patch context:</b> ${pm.patch||'—'} • ${pm.updated||'—'}.</li>
        </ul>
        <div class="sourceLinks">
          <a href="https://www.mobilelegends.com/rank" target="_blank" rel="noopener">Official Moonton Hero Ranking ↗</a>
          <a href="https://mlbbhub.com/tier-list" target="_blank" rel="noopener">MLBBHub Tier List ↗</a>
          <a href="https://mlbbdex.com/en/tier-list" target="_blank" rel="noopener">MLBBDex Tier List ↗</a>
          <a href="https://mlbbhub.com/patch-notes/original/2.2.16a" target="_blank" rel="noopener">Patch 2.2.16a Notes ↗</a>
        </div>
      </section>

      <section class="intelSection">
        <div class="sectionHeading"><div><span class="sectionKicker">CURATED / STRATEGIC</span><h3>What is not an official statistic</h3></div></div>
        <ul class="dataList">
          <li><b>Hero builds:</b> curated offline recommendations, not a live feed of every ranked player's items.</li>
          <li><b>Counters:</b> curated matchup relationships, not a complete live 133×133 statistical matrix.</li>
          <li><b>Synergy:</b> strategic recommendations, not official game statistics.</li>
          <li><b>Difficulty:</b> editorial guidance, not an official Moonton difficulty score.</li>
          <li><b>Draft score:</b> our heuristic combining matchup, role coverage, synergy, profile mastery and a small meta-tier signal.</li>
        </ul>
      </section>

      <section class="intelSection">
        <div class="sectionHeading"><div><span class="sectionKicker">CURRENT PATCH</span><h3>${pm.patch||'Patch'} changes included</h3></div></div>
        <div class="tipGrid">${(pm.changes||[]).map((x,i)=>`<div class="tipCard"><span>${i+1}</span><p>${x}</p></div>`).join('')}</div>
      </section>

      <section class="intelSection">
        <div class="sectionHeading"><div><span class="sectionKicker">ITEM DATA</span><h3>Why the item count is ${im.bundledItems}, not ${im.currentFullPool}</h3></div></div>
        <p class="muted">The app bundles the item records actually used by its offline hero recommendations instead of adding dozens of shop components with incomplete local details. Item costs were refreshed against the current item dataset. ${im.note||''}</p>
      </section>

      <button class="backBtn" onclick="dashboardPage()">← Back to Profile</button>
    </div>`;
}

/* ---------- Items ---------- */

function showItems(category = "All") {
  currentItemCategory = category;

  grid.innerHTML = `
    <div class="heroProfile">
      <div class="info">
        <h1>🗡️ MLBB Items</h1>
        <p class="muted">Core offline item set: ${typeof itemMeta !== "undefined" ? itemMeta.bundledItems : items.length} records. Current full shop pool is ${typeof itemMeta !== "undefined" ? itemMeta.currentFullPool : "not tracked"}; this app intentionally keeps the recommendation set compact.</p>

        <div class="filters">
          <button onclick="showItems('All')">All</button>
          <button onclick="showItems('Movement')">Boots</button>
          <button onclick="showItems('Physical Damage')">Physical</button>
          <button onclick="showItems('Magic Damage')">Magic</button>
          <button onclick="showItems('Physical Defense')">Physical Def</button>
          <button onclick="showItems('Magic Defense')">Magic Def</button>
          <button onclick="showItems('Hybrid Defense')">HP/Hybrid</button>
          <button onclick="showItems('Jungle')">Jungle</button>
          <button onclick="showItems('Roam')">Roam</button>
        </div>

        <input id="itemSearch"
               type="text"
               placeholder="Search Items..."
               oninput="filterItems()">

        <div id="itemList"></div>

        <button class="backBtn" onclick="showHeroes(heroes)">
          ⬅ Back
        </button>
      </div>
    </div>
  `;

  renderItems();
}

function renderItems() {
  const text = (document.getElementById("itemSearch")?.value || "")
    .toLowerCase()
    .trim();

  const filtered = items.filter(item => {
    const categoryMatch =
      currentItemCategory === "All" ||
      item.category === currentItemCategory;

    const textMatch =
      item.name.toLowerCase().includes(text);

    return categoryMatch && textMatch;
  });

  const list = document.getElementById("itemList");

  if (!list) return;

  list.innerHTML = filtered.map(item => `
    <div class="itemRow"
         onclick='itemPage(${jsArg(item.name)})'>
      <img class="itemImg"
           src="${itemAsset(item.name)}"
           alt="${item.name}"
           onerror="this.style.display='none'">

      <div class="itemInfo">
        <h3>${item.name}</h3>
        <span class="badge">${item.category}</span>
      </div>
    </div>
  `).join("");

  if (!filtered.length) {
    list.innerHTML = `<p class="muted">No items found.</p>`;
  }
}

function filterItems() {
  renderItems();
}

function itemPage(name) {
  const item = items.find(i => i.name === name);

  if (!item) {
    showItems();
    return;
  }

  const d = itemDetails[name] || {
    cost: "—",
    stats: "Details not added yet.",
    passive: "Details not added yet."
  };

  grid.innerHTML = `
    <div class="heroProfile">
      <div class="profileTop">
        <img class="profileHeroImg"
             src="${itemAsset(item.name)}"
             alt="${item.name}"
             onerror="this.style.display='none'">

        <div>
          <h1>${item.name}</h1>
          <span class="badge">${item.category}</span>
        </div>
      </div>

      <div class="info">
        <p><b>Price:</b> ${d.cost}</p>
        <p><b>Stats:</b> ${d.stats}</p>
        <p><b>Passive:</b> ${d.passive}</p>

        <button class="backBtn"
                onclick="showItems(currentItemCategory)">
          ← Back to Items
        </button>
      </div>
    </div>
  `;
}

/* ---------- Counter Picker ---------- */

function counterPage() {
  grid.innerHTML = `
    <div class="pagePanel">
      <h2>⚔ Counter Picker</h2>
      <p class="muted">Type a few letters and pick the hero instantly. Counter relationships in this offline pack are curated strategy data, not a claim of complete live matchup statistics.</p>

      <div class="counterWrap">
        <div class="fastHeroPicker">
          <input class="heroSearch" id="counterHeroSearch" type="search" placeholder="🔎 Type hero name..." autocomplete="off" oninput="renderHeroSuggestions(this, 'enemyHero', 'counterHeroSuggestions')" onkeydown="handleHeroSearchKey(event, this, 'enemyHero', 'counter')">
          <select id="enemyHero" class="pickerState" data-allow-blank="true" onchange="showCounter()">
            <option value="">Select Enemy Hero</option>
            ${sortedHeroes().map(h => `<option value="${h.name}">${h.name}</option>`).join("")}
          </select>
          <div id="counterHeroSuggestions" class="heroSuggestions"></div>
        </div>

        <div id="counterResult"></div>
      </div>
    </div>
  `;
}

function showCounter() {
  const enemy = document.getElementById("enemyHero")?.value;
  const result = document.getElementById("counterResult");

  if (!result) return;

  const c = counters[enemy];

  if (!enemy || !c) {
    result.innerHTML = "";
    return;
  }

  result.innerHTML = `
    <h3>Best Counters for ${enemy}</h3>

    <div class="itemBuild">
      ${c.weak.map(hero => `
        <div class="buildItem clickable"
             onclick='heroPage(${jsArg(hero)})'>
          <img class="itemImg"
               src="${heroAsset(hero)}"
               alt="${hero}"
               onerror="this.style.display='none'">
          <p>${hero}</p>
        </div>
      `).join("")}
    </div>
  `;
}

/* ---------- Draft Assistant ---------- */

function sortedHeroes() {
  return [...heroes].sort((a, b) => a.name.localeCompare(b.name));
}

function heroOptions(includeAny = false) {
  return (includeAny ? '<option value="">Select Hero</option>' : '<option value="">—</option>') +
    sortedHeroes().map(h => `<option value="${h.name}">${h.name}</option>`).join("");
}

function renderHeroSuggestions(input, selectId, suggestionsId) {
  const box = document.getElementById(suggestionsId);
  const select = document.getElementById(selectId);
  const inputOnly = selectId === 'heroMatchup';
  if (!box || (!select && !inputOnly)) return;

  const query = input.value.trim().toLowerCase();
  if (!query) {
    box.innerHTML = "";
    box.classList.remove("show");
    return;
  }

  const all = sortedHeroes();
  // Draft-pick suggestions prioritize heroes whose names START with the typed text.
  // Only then fall back to heroes that contain the text elsewhere in the name.
  const startsWith = all.filter(h => h.name.toLowerCase().startsWith(query));
  const contains = all.filter(h => !h.name.toLowerCase().startsWith(query) && h.name.toLowerCase().includes(query));
  const matches = [...startsWith, ...contains].slice(0, 8);
  if (!matches.length) {
    box.innerHTML = `<div class="heroSuggestionEmpty">No hero found</div>`;
    box.classList.add("show");
    return;
  }

  box.innerHTML = matches.map(h => `
    <button type="button" class="heroSuggestion" onclick='pickHeroSuggestion(${jsArg(h.name)}, ${jsArg(selectId)}, ${jsArg(suggestionsId)})'>
      <img src="${heroAsset(h.name)}" alt="${h.name}" onerror="this.style.visibility='hidden'">
      <span>${h.name}</span>
      <small>${h.role || ""}</small>
    </button>
  `).join("");
  box.classList.add("show");
}

function pickHeroSuggestion(heroName, selectId, suggestionsId) {
  const inputMap = {
    enemyHero: 'counterHeroSearch',
    heroMatchup: 'heroMatchup',
    myHero: 'myHeroSearch',
    ally1: 'ally1Search',
    ally2: 'ally2Search',
    enemy1: 'enemy1Search',
    enemy2: 'enemy2Search',
    enemy3: 'enemy3Search',
    enemy4: 'enemy4Search',
    enemy5: 'enemy5Search',
    ban1: 'ban1Search',
    ban2: 'ban2Search',
    ban3: 'ban3Search'
  };
  const input = document.getElementById(inputMap[selectId]);
  const select = document.getElementById(selectId);
  const box = document.getElementById(suggestionsId);
  if (!input) return;

  if (['myHero','ally1','ally2','enemy1','enemy2','enemy3','enemy4','enemy5','ban1','ban2','ban3'].includes(selectId) && !draftCanSelectHero(heroName, selectId)) return;
  input.value = heroName;
  if (select) select.value = heroName;
  if (box) { box.innerHTML = ""; box.classList.remove("show"); }

  if (selectId === 'heroMatchup') {
    analyzeHeroMatchup();
    return;
  }

  if (selectId === 'enemyHero') {
    showCounter();
    return;
  }

  // V7: once an enemy is entered, keep the analyzer live so the player does not
  // have to repeatedly press Analyze while building the draft.
  if (['enemy1','enemy2','enemy3','enemy4','enemy5','myHero','ally1','ally2','ban1','ban2','ban3'].includes(selectId) && document.getElementById('draftResult')) {
    if (getDraftEnemies().length) recommendDraft();
  }

  const order=['myHero','ally1','ally2','enemy1','enemy2','enemy3','enemy4','enemy5','ban1','ban2','ban3'];
  const i=order.indexOf(selectId);
  const next=i>=0?order[i+1]:null;
  if(next) document.getElementById(next+'Search')?.focus();
}

function filterHeroSelect(input, selectId) {
  const suggestionsId = selectId === 'enemyHero' ? 'counterHeroSuggestions' : `${selectId}Suggestions`;
  renderHeroSuggestions(input, selectId, suggestionsId);
}

function handleHeroSearchKey(event, input, selectId, mode) {
  if (event.key !== "Enter") return;
  event.preventDefault();

  const query = input.value.trim().toLowerCase();
  if (!query) return;

  const list = sortedHeroes();
  const exact = list.find(h => h.name.toLowerCase() === query);
  const startsWith = list.filter(h => h.name.toLowerCase().startsWith(query));
  const contains = list.filter(h => !h.name.toLowerCase().startsWith(query) && h.name.toLowerCase().includes(query));
  const match = exact || startsWith[0] || contains[0];
  if (!match) return;

  const suggestionsId = selectId === 'enemyHero' ? 'counterHeroSuggestions' : `${selectId}Suggestions`;
  pickHeroSuggestion(match.name, selectId, suggestionsId);
}

function draftUsedHeroIds(excludeId = '') {
  const ids = ['myHero','ally1','ally2','enemy1','enemy2','enemy3','enemy4','enemy5','ban1','ban2','ban3'];
  return new Set(ids.filter(id => id !== excludeId).map(id => document.getElementById(id)?.value).filter(Boolean));
}

function draftCanSelectHero(heroName, selectId) {
  const used = draftUsedHeroIds(selectId);
  if (!used.has(heroName)) return true;
  const box = document.getElementById(`${selectId}Suggestions`);
  if (box) {
    box.innerHTML = `<div class="heroSuggestionEmpty">${heroName} is already used in this draft.</div>`;
    box.classList.add('show');
  }
  return false;
}

function draftHeroOptions(includeAny = false) {
  return heroOptions(includeAny);
}

function getDraftEnemies() {
  return [1,2,3,4,5]
    .map(i => document.getElementById(`enemy${i}`)?.value)
    .filter(Boolean);
}

function draftRole(heroName) {
  const h = heroes.find(x => x.name === heroName);
  return h ? h.role.split(" • ")[0] : "Unknown";
}

function draftScoreCandidates(enemies, myHero) {
  const enemySet = new Set(enemies);
  const score = {};

  heroes.forEach(h => {
    if (enemySet.has(h.name) || h.name === myHero) return;
    score[h.name] = 0;
  });

  enemies.forEach(enemy => {
    const c = counters[enemy];
    if (!c) return;
    c.weak.forEach(candidate => {
      if (score[candidate] !== undefined) score[candidate] += 3;
    });
    c.strong.forEach(candidate => {
      if (score[candidate] !== undefined) score[candidate] -= 1;
    });
  });

  return Object.entries(score)
    .filter(([, value]) => value > 0)
    .sort((a, b) => b[1] - a[1]);
}

function draftThreats(myHero, enemies) {
  if (!myHero || !enemies.length) return [];
  const c = counters[myHero] || { weak: [], strong: [] };
  return enemies.map(enemy => {
    if (c.weak.includes(enemy)) return { enemy, level: "HIGH", cls: "dangerTag", reason: `${enemy} is a stored threat to ${myHero}.` };
    if (c.strong.includes(enemy)) return { enemy, level: "LOW", cls: "goodTag", reason: `${myHero} has a stored matchup advantage here.` };

    // Use the enemy's list as a reciprocal fallback so the draft analyzer
    // can still understand a matchup when only one side stores the pairing.
    const enemyData = counters[enemy] || { strong: [], weak: [] };
    if (enemyData.strong.includes(myHero)) return { enemy, level: "HIGH", cls: "dangerTag", reason: `${enemy} is listed as strong against ${myHero}.` };
    if (enemyData.weak.includes(myHero)) return { enemy, level: "LOW", cls: "goodTag", reason: `${enemy} is listed as weak against ${myHero}.` };

    const enemyHero = heroes.find(x => x.name === enemy);
    const enemyRole = (enemyHero?.role || "").toLowerCase();
    let reason = "Situational matchup: play around your win condition, wave state and objective timing.";
    if (enemyRole.includes("assassin")) reason = "Situational matchup: respect burst and flank angles; keep your escape or control tool available.";
    else if (enemyRole.includes("marksman")) reason = "Situational matchup: respect range and sustained damage; avoid long open-field trades without an advantage.";
    else if (enemyRole.includes("mage")) reason = "Situational matchup: respect burst and crowd control; punish after key spells are used.";
    else if (enemyRole.includes("fighter")) reason = "Situational matchup: maintain spacing and punish missed abilities instead of taking extended trades.";
    else if (enemyRole.includes("tank")) reason = "Situational matchup: do not waste your full burst on the frontline; play around their engage tools.";
    else if (enemyRole.includes("support")) reason = "Situational matchup: track peel and control cooldowns before committing.";
    return { enemy, level: "MED", cls: "neutralTag", reason };
  });
}

function draftGamePlan(myHero, enemies) {
  const h = heroes.find(x => x.name === myHero);
  const role = h ? h.role.toLowerCase() : "";
  const c = counters[myHero] || { weak: [], strong: [] };
  const hasAssassin = enemies.some(name => {
    const eh = heroes.find(x => x.name === name);
    return eh && eh.role.toLowerCase().includes("assassin");
  });
  const hasTank = enemies.some(name => {
    const eh = heroes.find(x => x.name === name);
    return eh && eh.role.toLowerCase().includes("tank");
  });

  const tips = [];
  if (c.weak.length && enemies.some(e => c.weak.includes(e))) {
    tips.push(`Respect ${enemies.filter(e => c.weak.includes(e)).slice(0,2).join(" and ")} and avoid isolated fights into their strongest window.`);
  }
  if (hasAssassin) tips.push("An assassin is present: prioritize vision, positioning and staying near teammates before committing damage.");
  if (hasTank) tips.push("A tank is present: do not waste your full combo on the frontline unless it creates a real objective advantage.");
  if (role.includes("gold")) tips.push("Gold lane: farm safely, hit your item timings and use your range advantage around objectives.");
  else if (role.includes("jungle")) tips.push("Jungle: route around objectives and punish exposed lanes instead of forcing low-probability ganks.");
  else if (role.includes("mid")) tips.push("Mid lane: clear first, then move with your team and keep river approaches covered.");
  else if (role.includes("roam")) tips.push("Roam: create space for your strongest teammate and make your engage/disengage count around objectives.");
  else if (role.includes("exp")) tips.push("EXP lane: manage the side lane, then rotate when your pressure can become an objective.");
  else tips.push("Play around your safest damage window and convert won fights into objectives.");

  return tips.slice(0, 4);
}

/* ---------- Tier List ---------- */

function tierPage(role = "All") {
  currentView = "tier";
  currentTierRole = role;
  search.value = "";
  search.placeholder = role === "All" ? "Search Tier List..." : `Search ${role} Tier List...`;
  renderTierList(role, "");
}

function renderTierList(role = "All", query = "") {
  const order = ["S", "A", "B", "C", "D", "Unranked"];
  const q = query.toLowerCase().trim();
  const roleFiltered = role === "All"
    ? heroes
    : heroes.filter(h => (h.role || "").toLowerCase().includes(role.toLowerCase()));

  const filtered = q
    ? roleFiltered.filter(h => h.name.toLowerCase().includes(q))
    : roleFiltered;

  const roleButtons = ["All", "Gold", "EXP", "Mid", "Jungle", "Roam"];

  grid.innerHTML = `
    <section class="tierControls pagePanel">
      <div class="sectionHeading">
        <div>
          <span class="sectionKicker">TIER LIST</span>
          <h2>Choose a Role</h2>
        </div>
        <span class="muted">${role === "All" ? "All roles" : role + " Lane"}</span>
      </div>
      <div class="tierRoleFilters">
        ${roleButtons.map(r => `
          <button class="${r === role ? "active" : ""}" onclick='tierPage(${jsArg(r)})'>${r}</button>
        `).join("")}
      </div>
      <p class="tierNote">Offline tier snapshot: Patch ${typeof tierMeta !== "undefined" ? tierMeta.patch : "local data"} • ${typeof tierMeta !== "undefined" ? tierMeta.updated : ""}. Tier labels are a ranked-data interpretation; Moonton itself publishes win/pick/ban statistics rather than S/A/B/C/D labels. <button class="backBtn smallBtn" onclick="dataPage()">Data sources</button></p>
    </section>

    ${order.map(tier => {
      const tierHeroes = filtered
        .filter(h => tierValue(h.name) === tier)
        .sort((a, b) => a.name.localeCompare(b.name));

      if (!tierHeroes.length) return "";

      return `
        <section class="tierSection">
          <h2>${tier} Tier</h2>

          <div class="grid">
            ${tierHeroes.map(h => `
              <div class="hero" onclick='heroPage(${jsArg(h.name)})'>
                <img class="heroImg"
                     src="${heroAsset(h.name)}"
                     alt="${h.name}"
                     onerror="this.style.display='none'">
                <span class="badge tierBadge">${tier}</span>
                <h3>${h.name}</h3>
                <p>${h.role}</p>
              </div>
            `).join("")}
          </div>
        </section>
      `;
    }).join("")}

    ${filtered.length ? "" : `<div class="pagePanel"><p class="muted">No heroes found for this role/search.</p></div>`}
  `;
}


/* ============================================================
   v5.3 FOUNDATION + FEATURE PACK
   - Never silently treats missing tier data as C.
   - Advanced draft: role preference + allies + enemies + bans.
   - Local dashboard + learning mode.
   - Favorites via localStorage.
   ============================================================ */

function tierValue(heroName) {
  return tiers[heroName] || "Unranked";
}

function getFavorites() {
  try {
    const value = JSON.parse(localStorage.getItem("mlbbFavorites") || "[]");
    return Array.isArray(value) ? value : [];
  } catch (e) {
    return [];
  }
}
function toggleFavorite(heroName) {
  const next = getFavorites();
  const updated = next.includes(heroName) ? next.filter(x => x !== heroName) : [...next, heroName];
  localStorage.setItem("mlbbFavorites", JSON.stringify(updated));
  const btn = document.getElementById("favoriteHeroBtn");
  if (btn) btn.textContent = updated.includes(heroName) ? "★ Favorited" : "☆ Add Favorite";
}

function getPlayerProfile(){
  const fallback={role:'Any',personalize:true,heroes:{},slots:['','','','','']};
  try{const raw=JSON.parse(localStorage.getItem('mlbbProfile')||'{}'); return Object.assign(fallback,raw,{heroes:raw.heroes||{},slots:Array.isArray(raw.slots)?raw.slots:['','','','','']});}catch(e){return fallback;}
}
function savePlayerProfile(profile){ localStorage.setItem('mlbbProfile', JSON.stringify(profile)); }
function profileLevel(name){ return getPlayerProfile().heroes?.[name] || ''; }
function profileNames(level){ const p=getPlayerProfile(); return Object.entries(p.heroes||{}).filter(([,v])=>v===level).map(([k])=>k); }
function setProfileHero(slot, name, level){
  const p=getPlayerProfile(); p.heroes=p.heroes||{}; p.slots=p.slots||['','','','',''];
  const old=p.slots[slot]||'';
  if(old && old!==name && !p.slots.some((x,i)=>i!==slot&&x===old)) delete p.heroes[old];
  p.slots[slot]=name||'';
  if(name) p.heroes[name]=level||'Comfortable';
  savePlayerProfile(p); profilePage();
}
function setProfileHeroLevel(slot, level){
  const p=getPlayerProfile(); p.heroes=p.heroes||{}; p.slots=p.slots||['','','','',''];
  const name=p.slots[slot]||'';
  if(!name) return;
  p.heroes[name]=level;
  savePlayerProfile(p); profilePage();
}
function clearProfileHero(slot){
  const p=getPlayerProfile(); p.heroes=p.heroes||{}; p.slots=p.slots||['','','','',''];
  const old=p.slots[slot]||'';
  if(old && !p.slots.some((x,i)=>i!==slot&&x===old)) delete p.heroes[old];
  p.slots[slot]=''; savePlayerProfile(p); profilePage();
}
function updateProfileRole(role){ const p=getPlayerProfile(); p.role=role; savePlayerProfile(p); }
function updateProfilePersonalize(on){ const p=getPlayerProfile(); p.personalize=!!on; savePlayerProfile(p); }
function profileSearchId(slot){ return `profileHero${slot}Search`; }
function profileSuggestionsId(slot){ return `profileHero${slot}Suggestions`; }
function renderProfileHeroSuggestions(input, slot){
  const box=document.getElementById(profileSuggestionsId(slot)); if(!box)return;
  const query=input.value.trim().toLowerCase();
  if(!query){box.innerHTML='';box.classList.remove('show');return;}
  const all=sortedHeroes();
  const starts=all.filter(h=>h.name.toLowerCase().startsWith(query));
  const contains=all.filter(h=>!h.name.toLowerCase().startsWith(query)&&h.name.toLowerCase().includes(query));
  const matches=[...starts,...contains].slice(0,8);
  box.innerHTML=matches.length?matches.map(h=>`<button type="button" class="heroSuggestion" onclick='pickProfileHero(${jsArg(h.name)},${slot})'><img src="${heroAsset(h.name)}" alt="${h.name}" onerror="this.style.visibility=\'hidden\'"><span>${h.name}</span><small>${h.role||''}</small></button>`).join(''):`<div class="heroSuggestionEmpty">No hero found</div>`;
  box.classList.add('show');
}
function pickProfileHero(name, slot){
  const p=getPlayerProfile();
  const duplicate=(p.slots||[]).some((x,i)=>i!==slot&&x===name);
  if(duplicate){ alert(`${name} is already in your hero pool.`); return; }
  const current=p.slots?.[slot]||'';
  const level=current?(p.heroes?.[current]||'Comfortable'):'Comfortable';
  setProfileHero(slot,name,level);
}
function handleProfileHeroKey(event,input,slot){
  if(event.key!=='Enter')return; event.preventDefault();
  const q=input.value.trim().toLowerCase(); if(!q)return;
  const all=sortedHeroes(); const exact=all.find(h=>h.name.toLowerCase()===q); const starts=all.find(h=>h.name.toLowerCase().startsWith(q)); const contains=all.find(h=>h.name.toLowerCase().includes(q));
  if(exact||starts||contains) pickProfileHero((exact||starts||contains).name,slot);
}
function profilePage(){
  currentView='profile'; search.value=''; search.placeholder='Search Hero...';
  const p=getPlayerProfile(); const entries=(p.slots||[]).map(name=>name?[name,p.heroes?.[name]||'Comfortable']:['','']);
  const levels=['Main','Comfortable','Learning','Avoid'];
  grid.innerHTML=`<div class="pagePanel profilePage">
    <div class="sectionHeading"><div><span class="sectionKicker">PLAYER PROFILE</span><h2>👤 My Draft Profile</h2><p class="muted">Tell the Companion which heroes you actually know. Draft recommendations will prefer your pool instead of blindly suggesting unfamiliar counters.</p></div></div>
    <section class="profileSetup">
      <div class="profileSetting"><label>🎯 Main Role</label><select id="profileRole" onchange="updateProfileRole(this.value)">${['Any','Gold','EXP','Mid','Jungle','Roam'].map(r=>`<option value="${r}" ${p.role===r?'selected':''}>${r}</option>`).join('')}</select></div>
      <label class="profileToggle"><input type="checkbox" ${p.personalize!==false?'checked':''} onchange="updateProfilePersonalize(this.checked)"><span><strong>Personalize draft recommendations</strong><small>When enabled, your hero comfort matters alongside matchup quality.</small></span></label>
    </section>
    <section class="profileSection"><div class="sectionHeading"><div><span class="sectionKicker">MY HERO POOL</span><h3>Comfort & Mastery</h3></div><span class="muted">Optional • up to 5 heroes</span></div>
      <div class="profileHeroRows">${[0,1,2,3,4].map(i=>{const current=entries[i]?.[0]||'';const level=entries[i]?.[1]||'Comfortable';return `<div class="profileHeroRow"><div class="fastHeroPicker"><input class="heroSearch profileHeroSearch" id="${profileSearchId(i)}" type="search" value="${current.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}" placeholder="🔎 Search your hero..." autocomplete="off" oninput="renderProfileHeroSuggestions(this,${i})" onkeydown="handleProfileHeroKey(event,this,${i})"><div id="${profileSuggestionsId(i)}" class="heroSuggestions"></div></div><div class="profileLevelButtons">${levels.map(x=>`<button type="button" class="profileLevelBtn ${level===x?'active':''} level-${x.toLowerCase()}" onclick='setProfileHeroLevel(${i},${jsArg(x)})'>${x}</button>`).join('')}</div><button type="button" class="profileClearBtn" onclick="clearProfileHero(${i})">Clear</button></div>`}).join('')}</div>
      <p class="profileHint"><strong>Main</strong> = strongest comfort pick • <strong>Comfortable</strong> = reliable • <strong>Learning</strong> = still practicing • <strong>Avoid</strong> = don't recommend unless necessary.</p>
    </section>
    <section class="profileSection"><div class="sectionHeading"><div><span class="sectionKicker">PROFILE EFFECT</span><h3>What the app will do</h3></div></div><div class="profileEffectGrid"><div><strong>${profileNames('Main').length}</strong><span>Main heroes</span></div><div><strong>${profileNames('Comfortable').length}</strong><span>Comfortable</span></div><div><strong>${profileNames('Learning').length}</strong><span>Learning</span></div><div><strong>${profileNames('Avoid').length}</strong><span>Avoid</span></div></div><p class="muted">Example: a slightly weaker counter that you master can outrank a perfect counter you have never played.</p></section>
    <section class="dashboardSection"><div class="sectionHeading"><div><span class="sectionKicker">QUICK TOOLS</span><h3>Jump In</h3></div></div><div class="dashboardActions"><button class="actionBtn" onclick="draftAssistant()">🎮 Advanced Draft</button><button class="actionBtn" onclick="tierPage()">🏆 Tier List</button><button class="actionBtn" onclick="showItems()">🗡️ Item Lab</button><button class="actionBtn" onclick="learningMode()">🧠 Learning Mode</button><button class="actionBtn" onclick="showHeroes(heroes)">👥 Hero Roster</button></div></section>
  </div>`;
}

const dashboardPage = profilePage;

function learningMode() {
  currentView = "learning";
  search.value = "";
  search.placeholder = "Learning Mode";
  const pool = heroes.slice().sort(() => Math.random() - 0.5).slice(0, 5);
  const state = { index: 0, score: 0, answered: false };
  window.learningState = state;
  window.learningPool = pool;
  renderLearningQuestion();
}

function renderLearningQuestion() {
  const state = window.learningState, pool = window.learningPool;
  if (!state || !pool) return;
  if (state.index >= pool.length) {
    grid.innerHTML = `<div class="pagePanel learningPage"><div class="sectionKicker">SESSION COMPLETE</div><h2>🧠 ${state.score}/${pool.length}</h2><p class="muted">Nice. Run another session to keep drilling the roster.</p><button class="actionBtn" onclick="learningMode()">New Session</button><button class="backBtn" onclick="dashboardPage()">Dashboard</button></div>`;
    return;
  }
  const h = pool[state.index];
  const questions = [
    { q: `What is ${h.name}'s primary role?`, answer: (h.role || "").split(" • ")[0] },
    { q: `What difficulty is ${h.name}?`, answer: h.difficulty },
    { q: `What tier is ${h.name} currently assigned?`, answer: tierValue(h.name) },
  ];
  const picked = questions[Math.floor(Math.random() * questions.length)];
  state.currentAnswer = picked.answer;
  state.currentQuestion = picked.q;
  const distractors = heroes.map(x => (x.role || "").split(" • ")[0]).concat(["Easy","Medium","Hard","S","A","B","C","D","Unranked"]);
  const opts = [...new Set([picked.answer, ...distractors.sort(() => Math.random()-0.5).slice(0,3)])].slice(0,4).sort(() => Math.random()-0.5);
  grid.innerHTML = `<div class="pagePanel learningPage"><div class="sectionKicker">LEARNING MODE • ${state.index+1}/${pool.length}</div><h2>${picked.q}</h2><img class="learningHeroImg" src="${heroAsset(h.name)}" alt="${h.name}"><div class="quizOptions">${opts.map(o => `<button onclick='answerLearning(${jsArg(o)})'>${o}</button>`).join("")}</div><div id="learningFeedback" class="learningFeedback"></div><button class="backBtn" onclick="dashboardPage()">Exit</button></div>`;
}

function answerLearning(answer) {
  const state = window.learningState;
  if (!state || state.answered) return;
  state.answered = true;
  const good = answer === state.currentAnswer;
  if (good) state.score++;
  const box = document.getElementById("learningFeedback");
  if (box) box.innerHTML = `<strong>${good ? "✅ Correct" : "❌ Not quite"}</strong><p>Answer: ${state.currentAnswer}</p><button class="actionBtn" onclick="nextLearning()">Next</button>`;
}
function nextLearning() { window.learningState.index++; window.learningState.answered=false; renderLearningQuestion(); }

function heroPage(name) {
  baseHeroPageV53(name);
  const h = heroes.find(x => x.name === name);
  if (!h) return;
  const fav = getFavorites().includes(name);
  const target = document.querySelector(".heroProfileHeading");
  if (target && !document.getElementById("favoriteHeroBtn")) {
    const btn = document.createElement("button");
    btn.id = "favoriteHeroBtn";
    btn.className = "favoriteBtn";
    btn.textContent = fav ? "★ Favorited" : "☆ Add Favorite";
    btn.onclick = () => toggleFavorite(name);
    target.appendChild(btn);
  }
}

function getSelected(id){ return document.getElementById(id)?.value || ""; }
function getDraftAllies(){ return ["ally1","ally2"].map(getSelected).filter(Boolean); }
function getDraftBans(){ return ["ban1","ban2","ban3"].map(getSelected).filter(Boolean); }

/* ---------- v6.0 Advanced Draft & Match Intelligence ---------- */
function v6Hero(name){ return heroes.find(h => h.name === name); }
function v6RoleText(name){ return (v6Hero(name)?.role || '').toLowerCase(); }
function v6LaneRoles(name){ const r=v6RoleText(name), out=[]; [['gold','Gold'],['exp','EXP'],['mid','Mid'],['jungle','Jungle'],['roam','Roam']].forEach(([k,v])=>{if(r.includes(k))out.push(v);}); return out; }
function v6Archetypes(name){ const r=v6RoleText(name), out=[]; ['tank','fighter','assassin','mage','marksman','support'].forEach(x=>{if(r.includes(x))out.push(x);}); return out; }
function v6DirectRelation(a,b){ const ca=counters[a]||{strong:[],weak:[]}, cb=counters[b]||{strong:[],weak:[]}; if((ca.weak||[]).includes(b)||(cb.strong||[]).includes(a))return'bad'; if((ca.strong||[]).includes(b)||(cb.weak||[]).includes(a))return'good'; return'neutral'; }
function v6Synergy(a,b){ return (synergy[a]||[]).includes(b)||(synergy[b]||[]).includes(a); }
function v6Unique(list){ return [...new Set(list.filter(Boolean))]; }
function v6DraftInputs(){ const p=getPlayerProfile(); const selected=getSelected('draftPreferredRole')||'Any'; return {myHero:getSelected('myHero'),allies:getDraftAllies(),enemies:getDraftEnemies(),bans:getDraftBans(),preferred:selected==='Any'&&p.role&&p.role!=='Any'?p.role:selected}; }
function v6RoleCoverage(names){ const text=names.map(v6RoleText).join(' '); return {frontline:/tank|fighter/.test(text),magic:/mage/.test(text),physical:/marksman|fighter|assassin/.test(text),control:/tank|mage|support/.test(text),engage:/tank|fighter|assassin|support/.test(text),ranged:/marksman|mage/.test(text)}; }
function v7Clamp(n,min=0,max=100){ return Math.max(min,Math.min(max,n)); }
function v7RelationScore(rel){ return rel==='good'?1:rel==='bad'?-1:0; }
function v6CandidateScore(candidate,input){
  const {myHero,allies,enemies,preferred,bans}=input;
  const picked=v6Unique([myHero,...allies,...enemies,...bans]);
  if(picked.includes(candidate)) return {score:-999,reasons:[],breakdown:{}};

  const lanes=v6LaneRoles(candidate), tier=tierValue(candidate), ar=v6Archetypes(candidate);
  const breakdown={role:0,counter:0,synergy:0,composition:0,mastery:0,meta:0};
  const reasons=[];

  // Role fit: important, but never strong enough to overpower a disastrous matchup.
  if(preferred==='Any') breakdown.role=7;
  else if(lanes.includes(preferred)){ breakdown.role=15; reasons.push('fits your preferred role'); }
  else breakdown.role=0;

  // Matchup score: reward multiple favorable edges, punish direct threats.
  let wins=0,losses=0;
  enemies.forEach(enemy=>{
    const rel=v6DirectRelation(candidate,enemy);
    if(rel==='good') wins++;
    if(rel==='bad') losses++;
  });
  breakdown.counter=v7Clamp(15 + wins*7 - losses*10,0,30);
  if(wins) reasons.push(wins===1?'has a favorable matchup':'covers multiple enemy matchups');
  if(losses) reasons.push(losses===1?'has one matchup concern':'has several matchup concerns');

  // Ally synergy.
  let syn=0;
  allies.forEach(ally=>{ if(v6Synergy(candidate,ally)) syn++; });
  breakdown.synergy=v7Clamp(syn*7.5,0,15);
  if(syn) reasons.push(syn===1?'fits an ally synergy':'fits multiple ally synergies');

  // Composition: reward filling missing strategic functions.
  const current=v6Unique([myHero,...allies]), cov=v6RoleCoverage(current);
  if(!cov.frontline && ar.some(x=>x==='tank'||x==='fighter')){ breakdown.composition+=5; reasons.push('adds frontline'); }
  if(!cov.magic && ar.includes('mage')){ breakdown.composition+=4; reasons.push('adds magic damage'); }
  if(!cov.control && ar.some(x=>x==='tank'||x==='mage'||x==='support')){ breakdown.composition+=3; reasons.push('adds control'); }
  if(!cov.ranged && ar.some(x=>x==='marksman'||x==='mage')){ breakdown.composition+=2; reasons.push('adds ranged damage'); }
  if(!cov.engage && ar.some(x=>x==='tank'||x==='fighter'||x==='assassin'||x==='support')){ breakdown.composition+=2; reasons.push('adds engage/access'); }
  breakdown.composition=v7Clamp(breakdown.composition,0,15);

  // Player mastery is a major signal, but strategic fit still matters.
  const profile=getPlayerProfile();
  const comfort=profile.heroes?.[candidate]||'';
  if(profile.personalize!==false){
    if(comfort==='Main'){breakdown.mastery=20; reasons.unshift('you main this hero');}
    else if(comfort==='Comfortable'){breakdown.mastery=14; reasons.unshift('you are comfortable on this hero');}
    else if(comfort==='Learning'){breakdown.mastery=6; reasons.unshift('you are learning this hero');}
    else if(comfort==='Avoid'){breakdown.mastery=0; reasons.unshift('marked Avoid in your profile');}
  } else breakdown.mastery=10;

  // Meta is deliberately a small signal: current tier should not override matchup or mastery.
  breakdown.meta=tier==='S'?5:tier==='A'?4:tier==='B'?3:tier==='C'?2:tier==='D'?1:0;
  if(tier==='S') reasons.push('current S-tier meta signal');
  else if(tier==='A') reasons.push('current A-tier meta signal');

  const score=Math.round(v7Clamp(breakdown.role+breakdown.counter+breakdown.synergy+breakdown.composition+breakdown.mastery+breakdown.meta));
  return {score,reasons:v6Unique(reasons).slice(0,4),counterWins:wins,counterLosses:losses,synergies:syn,profileLevel:comfort||'',breakdown};
}
function v6RankCandidates(input){ const banned=new Set(v6Unique([...input.allies,...input.enemies,...input.bans,input.myHero])); return heroes.filter(h=>!banned.has(h.name)).map(h=>({hero:h.name,...v6CandidateScore(h.name,input)})).sort((a,b)=>b.score-a.score||a.hero.localeCompare(b.hero)); }
function v6ProfileCandidates(input){
  const banned=new Set(v6Unique([...input.allies,...input.enemies,...input.bans,input.myHero]));
  const p=getPlayerProfile();
  const heroNames=new Set(heroes.map(h=>h.name));
  const pool=Object.entries(p.heroes||{}).filter(([name,level])=>heroNames.has(name) && level && level!=='Avoid' && !banned.has(name));
  return pool.map(([hero,level])=>{const base=v6CandidateScore(hero,input); return {...base,hero,profileLevel:level};})
    .sort((a,b)=>b.score-a.score||a.hero.localeCompare(b.hero));
}
function v6EnemyThreats(input){
  const team=v6Unique([input.myHero,...input.allies]);
  return input.enemies.map(enemy=>{let danger=0,reasons=[];team.forEach(ally=>{const rel=v6DirectRelation(enemy,ally);if(rel==='bad'){danger+=3;reasons.push('pressures '+ally);}else if(rel==='good')danger-=1;});const enemyTier=tierValue(enemy);if(enemyTier==='S'){danger+=2;reasons.push('current S-tier threat');}else if(enemyTier==='A'){danger+=1;reasons.push('current A-tier threat');}const arch=v6Archetypes(enemy);if(arch.includes('assassin')){danger+=2;reasons.push('burst/flank threat');}if(arch.includes('marksman')){danger+=1;reasons.push('sustained damage');}if(arch.includes('mage')){danger+=1;reasons.push('burst/control');}if(arch.includes('tank')){danger+=1;reasons.push('frontline/engage');}if(arch.includes('fighter')){danger+=1;reasons.push('dive/sustained damage');}return{enemy,level:danger>=5?'HIGH':danger>=2?'MED':'LOW',danger,reasons:v6Unique(reasons).slice(0,3)};}).sort((a,b)=>b.danger-a.danger);
}
function v6CompositionScore(input,picks){
  const team=v6Unique([input.myHero,...input.allies]);let score=50;const cov=v6RoleCoverage(team);if(cov.frontline)score+=10;else score-=7;if(cov.magic)score+=7;else score-=4;if(cov.physical)score+=7;if(cov.control)score+=7;else score-=4;if(cov.engage)score+=5;else score-=4;
  if(input.myHero)input.enemies.forEach(e=>{const rel=v6DirectRelation(input.myHero,e);if(rel==='good')score+=3;if(rel==='bad')score-=4;});
  let syn=0;input.allies.forEach(a=>{if(v6Synergy(input.myHero,a))syn++;});score+=Math.min(8,syn*3);if(picks.length)score+=Math.min(6,Math.max(0,picks[0].score-6));return Math.max(0,Math.min(100,Math.round(score)));
}
function v6ScoreLabel(score){return score>=75?'Strong':score>=58?'Playable':score>=42?'Situational':'Risky';}
function v6BuildPlan(input,topPick){
  const tips=[],team=v6Unique([input.myHero,...input.allies]),cov=v6RoleCoverage(team);if(!input.myHero)tips.push('You have not locked your hero yet — use the top picks as your next-pick shortlist.');if(!cov.frontline)tips.push('Your current team lacks a clear frontline; prioritize a durable fighter or tank.');if(!cov.magic)tips.push('Your current team lacks obvious magic damage; a mage can diversify the damage profile.');if(!cov.control)tips.push('Your team has limited reliable control; favor a hero that can start or stop fights.');if(input.enemies.some(e=>v6Archetypes(e).includes('assassin')))tips.push('Enemy assassin detected: protect your damage dealers and value peel/vision.');if(input.enemies.some(e=>v6Archetypes(e).includes('tank')))tips.push('Enemy frontline detected: keep sustained damage available instead of dumping everything into the tank.');if(input.preferred!=='Any'&&topPick&&!v6LaneRoles(topPick.hero).includes(input.preferred))tips.push('Your preferred '+input.preferred+' role has limited strong options; consider widening the role if possible.');return tips.slice(0,4);
}
function v6ReasonText(p){return p.reasons.length?p.reasons.slice(0,4).join(' • '):'balanced fallback option';}
function v7BreakdownHtml(p){
  const b=p.breakdown||{};
  return `<div class="v7Breakdown"><span>Role <b>${Math.round(b.role||0)}</b></span><span>Counter <b>${Math.round(b.counter||0)}</b></span><span>Synergy <b>${Math.round(b.synergy||0)}</b></span><span>Comp <b>${Math.round(b.composition||0)}</b></span><span>Mastery <b>${Math.round(b.mastery||0)}</b></span><span>Meta <b>${Math.round(b.meta||0)}</b></span></div>`;
}
function v7UseDraftPick(name){
  const ids=['myHero','ally1','ally2'];
  if(draftUsedHeroIds().has(name)) return;
  const target=ids.find(id=>!document.getElementById(id)?.value);
  if(!target) return;
  const search=document.getElementById(target+'Search');
  const select=document.getElementById(target);
  if(select) select.value=name;
  if(search) search.value=name;
  const box=document.getElementById(target+'Suggestions');
  if(box){box.innerHTML='';box.classList.remove('show');}
  document.querySelectorAll('.heroSearch').forEach(x=>{if(x!==search&&x.value===name)x.value='';});
  recommendDraft();
}
function v6DraftUI(){
  const picker=(label,id,placeholder,allowBlank=true)=>`<div class="draftBlock"><label>${label}</label><div class="fastHeroPicker"><input class="heroSearch" id="${id}Search" type="search" placeholder="${placeholder}" autocomplete="off" oninput="renderHeroSuggestions(this, '${id}', '${id}Suggestions')" onkeydown="handleHeroSearchKey(event, this, '${id}', 'draft')"><select id="${id}" class="pickerState draftEnemy" data-allow-blank="${allowBlank}">${draftHeroOptions(allowBlank)}</select><div id="${id}Suggestions" class="heroSuggestions"></div></div></div>`;
  grid.innerHTML=`<div class="pagePanel draftPage v6DraftPage"><div class="draftHero"><div><div class="sectionKicker">V7 • DRAFT INTELLIGENCE</div><h2>🎮 Draft Assistant</h2><p class="muted">Counter + synergy + composition + your mastery, with meta used only as a small tiebreaker.</p></div><button class="backBtn" onclick="dashboardPage()">Dashboard</button></div><div class="v7DraftLegend"><span><b>Fast input</b> type 1–2 letters and tap a hero</span><span><b>Personalized</b> your Main/Comfortable heroes get priority</span><span><b>Strategic</b> counters never override an impossible draft</span></div><div class="draftAdvancedTop"><div class="draftBlock"><label>🎯 Preferred Role</label><select id="draftPreferredRole" onchange="updateProfileRole(this.value)">${(()=>{const r=getPlayerProfile().role||'Any'; return ['Any','Gold','EXP','Mid','Jungle','Roam'].map(x=>`<option ${x===r?'selected':''}>${x}</option>`).join('')})()}</select></div></div><div class="draftSubhead">YOUR TEAM</div><div class="draftControls v6TeamGrid">${picker('🧑 Your Hero','myHero','🔎 Type your hero...',true)}${picker('🤝 Ally 1','ally1','🔎 Type ally...',true)}${picker('🤝 Ally 2','ally2','🔎 Type ally...',true)}</div><div class="draftSubhead">ENEMY TEAM</div><div class="draftControls">${[1,2,3,4,5].map(i=>picker('⚔️ Enemy '+i,'enemy'+i,'🔎 Type hero...',true)).join('')}</div><div class="draftSubhead">BANS <span class="muted">(optional)</span></div><div class="draftControls v6BanGrid">${[1,2,3].map(i=>picker('🚫 Ban '+i,'ban'+i,'🔎 Type hero...',true)).join('')}</div><div class="draftButtons"><button class="actionBtn draftAnalyzeBtn" onclick="recommendDraft()">🧠 Analyze Draft</button><button class="backBtn" onclick="draftAssistant()">↻ Reset</button></div><div id="draftResult"></div></div>`;
}
function recommendDraft(){
  const input=v6DraftInputs(),result=document.getElementById('draftResult');if(!result)return;
  if(!input.enemies.length){result.innerHTML=`<div class="draftEmpty"><h3>Add at least one enemy.</h3><p class="muted">Enter even one enemy to start. More enemies, allies and bans make the recommendation sharper.</p></div>`;return;}
  const allRanked=v6RankCandidates(input),profileRanked=v6ProfileCandidates(input),ranked=allRanked.slice(0,5),threats=v6EnemyThreats(input),high=threats.filter(x=>x.level==='HIGH').length,comp=v6CompositionScore(input,ranked),label=v6ScoreLabel(comp),top=ranked[0],plan=v6BuildPlan(input,top),locked=v6Unique([input.myHero,...input.allies]).length;
  const threatHtml=`<section class="draftSection"><div class="sectionHeading"><div><span class="sectionKicker">ENEMY WIN CONDITIONS</span><h3>What You Need to Respect</h3></div><span class="muted">${high} high priority</span></div><div class="draftThreatGrid v6ThreatGrid">${threats.map(t=>`<div class="draftThreat ${t.level==='HIGH'?'v6HighThreat':''}"><div><strong>${t.enemy}</strong><span class="badge ${t.level==='HIGH'?'dangerTag':t.level==='LOW'?'goodTag':'neutralTag'}">${t.level}</span></div><p>${t.reasons.length?t.reasons.join(' • '):'No major stored threat detected.'}</p></div>`).join('')}</div></section>`;
  const card=(p,i,profile=false)=>`<div class="draftPick v6Pick ${profile?'v6ProfilePick':''}"><div class="pickRank">#${i+1}</div><img src="${heroAsset(p.hero)}" alt="${p.hero}" onclick='heroPage(${jsArg(p.hero)})' onerror="this.style.display='none'"><div class="v7PickBody"><strong>${p.hero}</strong><span>${p.profileLevel?p.profileLevel+' • ':''}${draftRole(p.hero)}</span><small>${v6ReasonText(p)}</small>${v7BreakdownHtml(p)}</div><b class="v7Score">${p.score}</b><button class="v7UseBtn" onclick='v7UseDraftPick(${jsArg(p.hero)})'>＋ Use pick</button></div>`;
  const poolHtml=profileRanked.length?`<section class="draftSection"><div class="sectionHeading"><div><span class="sectionKicker">YOUR POOL</span><h3>Best Picks You Actually Know</h3></div><span class="muted">Mastery-aware</span></div><div class="draftPickGrid v6PickGrid">${profileRanked.slice(0,3).map((p,i)=>card(p,i,true)).join('')}</div><p class="muted">Main and Comfortable heroes receive a meaningful advantage, but matchup and team composition still matter.</p></section>`:`<section class="draftSection"><div class="sectionHeading"><div><span class="sectionKicker">YOUR POOL</span><h3>No available profile picks</h3></div></div><p class="muted">Your configured heroes are unavailable or marked Avoid. Strategic picks are shown below.</p></section>`;
  const picksHtml=`${poolHtml}<section class="draftSection"><div class="sectionHeading"><div><span class="sectionKicker">NEXT PICK</span><h3>Best Strategic Options</h3></div><span class="muted">0–100 decision score</span></div><div class="draftPickGrid v6PickGrid">${ranked.map((p,i)=>card(p,i)).join('')||`<p class="muted">No candidate survived the current draft constraints.</p>`}</div></section>`;
  const planHtml=`<section class="draftSection"><div class="sectionHeading"><div><span class="sectionKicker">DRAFT PLAN</span><h3>How to Finish the Composition</h3></div></div><div class="tipGrid draftTips">${plan.map((x,i)=>`<div class="tipCard"><span>${i+1}</span><p>${x}</p></div>`).join('')}</div></section>`;
  result.innerHTML=`<div class="v6ScoreBar"><div class="v6ScoreCircle"><strong>${comp}</strong><span>/100</span></div><div><span class="sectionKicker">DRAFT STRENGTH</span><h3>${label}</h3><p>${locked}/3 allied slots entered • ${input.enemies.length}/5 enemies entered • ${input.bans.length} bans</p></div></div>${threatHtml}${picksHtml}${planHtml}`;
}
draftAssistant=v6DraftUI;


/* ---------- V8 PWA / mobile shell ---------- */
let deferredInstallPrompt = null;
function initV8PWA(){
  const installBtn = document.getElementById('installBtn');
  const status = document.getElementById('offlineStatus');
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
  }
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    deferredInstallPrompt = event;
    if (installBtn) installBtn.hidden = false;
  });
  if (installBtn) installBtn.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    try { await deferredInstallPrompt.userChoice; } catch(e) {}
    deferredInstallPrompt = null;
    installBtn.hidden = true;
  });
  window.addEventListener('appinstalled', () => { if (installBtn) installBtn.hidden = true; });
  const refreshStatus = () => {
    if (!status) return;
    status.textContent = navigator.onLine ? '● Ready' : '● Offline';
    status.classList.toggle('offline', !navigator.onLine);
  };
  window.addEventListener('online', refreshStatus);
  window.addEventListener('offline', refreshStatus);
  refreshStatus();
}
initV8PWA();
